<!-- header -->
<div class="top">
    <div class="top-week">
        <div class="top-img-w" title="Number of week">
            <span class="circ"></span>
            <?php $this->html(self::$app->week()); ?>
        </div>
    </div>
    <img src="/server/src/image/wifi.png" class="wf" alt="WIFI OFF">
    <img src="/server/src/image/theme.png" id="theme" alt="Сменить тему" title="Сменить тему">
    <img src="/server/src/image/shed_m.png" class="hiden-bar" alt="hiden" onclick="bar()">
</div>
<!-- /header -->

<!-- user window -->
<div class="u-window">
    <div class="u-w-inner">
        <a href="." class="t-exit" title="exit"></a>
        <div class="u-w-i-name"></div>
        <fieldset class="w-u-f">
            <legend>Учетные данные</legend>
            <div class="w-u-err"></div>
            <div class="u-i-name">
                Имя: <input type="text" class="w-u-n" disabled="true" value="">
                <i class="w-u-n-i-f"></i>
                <i class="w-u-n-sv"></i>
            </div>
            <div class="u-i-name">
                Пароль: <i class="w-u-n-i"></i>
            </div>
            <fieldset class="u-i-psw">
                <legend>
                    Смена пароля
                </legend>
                <input type="password" class="chn-psw c-p-old" placeholder="Старый пароль">
                <input type="password" class="chn-psw c-p-new" placeholder="Новый пароль">
                <div id="u-i-ch" title="Сохранить"></div>
            </fieldset>
        </fieldset>
    </div>
</div>
<!-- /user window -->

<!-- fixed menu -->
<div class="left">
    <div class="left-icon">
        <img src="/server/src/image/icon.png" class="user" alt="icon">
        <div class="left-icon-name">
            User
        </div>
    </div>
    <div class="left-menu">
        <ul id="l-m">
            <li class="l-m-li" data-val="?menu=main" id="l-m-f">
                <img class="l-m-img" src="/server/src/image/imp2.png">
                <div class="text">
                    IMPORTANT
                </div>
            </li>

            <li class="l-m-li" data-val="?menu=result">
                <img class="l-m-img" src="/server/src/image/scanR.png">
                <div class="text">
                    SCAN RESULT
                </div>
                <span class="left-menu-span"> </span>
            </li>

            <li class="l-m-li" data-val="?menu=err">
                <img class="l-m-img" src="/server/src/image/error.png">
                <div class="text">
                    ERRORS
                </div>
            </li>

            <li class="l-m-li" data-val="?menu=shed">
                <img class="l-m-img" src="/server/src/image/sched.png">
                <div class="text">
                    SCHEUDULE
                </div>
            </li>

            <li class="l-m-li" data-val="?menu=config">
                <img class="l-m-img" src="/server/src/image/conf.png">
                <div class="text">
                    CONFIGURATION
                </div>
            </li>
        </ul>
    </div>

    <div class="left-footer">
        <img src="/server/src/image/vk.png" alt="vk">
        <img src="/server/src/image/tg.png" alt="tg">
        <div class="left-footer-about">
            &copy; Все права защищены Еммануил 2021
        </div>
    </div>
</div>
<!-- /fixed menu -->


<!-- worked content -->
<div id="full-right" class="full-right">
    <!-- screen status -->
    <div class="full-right-status">
        <div class="f-l-status">
            <div title="Stop Scanner" class="status-on" onclick="sendAjax('?cng=1', getStatusIter)">
                <div class="status-inner-r">
                    <div class="status-run">
                    </div>
                </div>
            </div>
            <div class="full-text">
                <div class="text-active">
                    <div class="text-status"> SCANNER LAUNCHED </div>
                    Last scan:
                    <div class="date"> </div>
                </div>
            </div>
        </div>
        <div class="f-l-status">
            <div title="Run Scanner" class="status-off" onclick="sendAjax('?cng=1', getStatusIter)">
                <div class="status-inner">
                    <div class="status-stop"> </div>
                </div>
            </div>
            <div class="full-text">
                <div class="text-active">
                    <div class="text-status-n"> SCANNER NOT ACTIVATED </div>
                    Last scan:
                    <div class="date"> </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /screen status -->

    <!-- loaded content -->
    <div id="content">
    </div>
    <!-- /loaded content -->
</div>
<!-- /worked content -->

/**
 * Я не работаю на js, и поэтому если вам
 * отвратительно от этого кода, уверяю вас,
 * мне в миллионы раз отвратительнее было это писать
 */

//let rel = document.getElementById('themelink')
let selected = document.getElementById('l-m-f')
let framed = null
let shedId = null
let shedGroup = ''
let user = null

function getMenu (answ) {
  document.getElementById('content').innerHTML = answ
  switch (selected.dataset.val) {
    case '?menu=shed':
      sendAjax('?menu=shed_inner', function (ans) {
        document.getElementById('t-t-shed').innerHTML = ans
        document.getElementById('full-right').classList.remove('load-content')
      })
      break
    case '?menu=config':
      document.getElementById('full-right').classList.remove('load-content')
      confEdit()
      break
    case '?menu=main':
      document.getElementById('full-right').classList.remove('load-content')
      document.body.classList.remove('load-content')
            sendAjax('?canvas=1', function (ans) {
        //console.log((ans))
        canvasStat(
          JSON.parse(ans)[0],
          JSON.parse(ans)[1],
          JSON.parse(ans)[2],
          document.querySelector('.t-s-content')
        )
      })
      break
    default:
      document.getElementById('full-right').classList.remove('load-content')
      document.body.classList.remove('load-content')
      break
  }
}

function onlineIs () {
  if (!navigator.onLine) {
    document.querySelector('.wf').classList.add('wf-ns')
  } else {
    document.querySelector('.wf').classList.remove('wf-ns')
  }
  setTimeout('onlineIs()', 10000)
}

function confEdit () {
  var line = document.querySelectorAll('input[type="range"]')
  let target = document.querySelectorAll('.v-value')
  let stTus = document.getElementById('lb-st')
  let old_val = [target[0].innerHTML, target[1].innerHTML]
  line[0].addEventListener('input', function () {
    target[0].innerHTML = line[0].value
  })
  line[1].addEventListener('input', function () {
    target[1].innerHTML = line[1].value
  })
  line[0].addEventListener('click', function () {
    if (target[0].innerHTML != old_val[0]) {
      sendAjax('?save=iter&vll=' + target[0].innerHTML)
      //console.log('?save=iter&vll=' + target[0].innerHTML)
    }
  })
  line[1].addEventListener('click', function () {
    if (target[1].innerHTML != old_val[1]) {
      sendAjax('?save=life&vll=' + target[1].innerHTML * 3600 * 24)
      //console.log('?save=life&vll=' + target[1].innerHTML * 3600 * 24)
    }
  })
  stTus.addEventListener('click', function () {
    if (stTus.classList.contains('lb-off')) {
      stTus.classList.add('lb-on')
      stTus.classList.remove('lb-off')
      sendAjax('?save=work&vll=1')
    } else {
      stTus.classList.remove('lb-on')
      stTus.classList.add('lb-off')
      sendAjax('?save=work&vll=0')
    }
  })
}

function getStatusIter (answ) {
  if (answ === false) {
    console.log('Ошибка соединения')
  } else {
    // change status
    let scan = document.getElementsByClassName('f-l-status')
    if ((answ = JSON.parse(answ))[0] == 1) {
      scan[0].classList.add('status-active')
      scan[1].classList.remove('status-active')
      document.getElementsByClassName('date')[0].innerHTML = answ[1]
      setTimeout("sendAjax('?status=1', getStatusIter)", 25000)
    } else {
      scan[1].classList.add('status-active')
      scan[0].classList.remove('status-active')
      document.getElementsByClassName('date')[1].innerHTML = answ[1]
    }
    // check theme
    if (answ[2] != null) {
      if (rel.getAttribute('href') != answ[2]) rel.href = answ[2]
    }
    if (answ[3] != null) {
      if (user != answ[3]) {
        user = answ[3]
        document.querySelector('.left-icon-name').innerHTML = answ[3]
      }
    }
  }
  // update active page but not shed.page
  if (selected.dataset.val != '?menu=shed') {
    sendAjax(selected.dataset.val, getMenu)
  }
}

chs = null
chsv = null
function hiden_groups (val, node) {
  let shedUl = document.getElementsByClassName('shed-ul')
  let faqImg = document.getElementsByClassName('faq-img')
  if (chs !== null && chsv != null) {
    chs.classList.remove('faq-li-after')
    shedUl[chsv].classList.remove('shed-ul-after')
    faqImg[chsv].classList.remove('rotate')
  }
  chs = node
  chsv = val
  node.classList.toggle('faq-li-after')
  shedUl[val].classList.toggle('shed-ul-after')
  faqImg[val].classList.toggle('rotate')
}

function frame (grp, chk = null) {
  //let wn = document.querySelector('.p-i-last')
  let frame = document.querySelector('.frame')
  document.getElementById('visible').style.display = 'none'
  if (frame.classList.contains('frame-hiden')) {
    frame.classList.remove('frame-hiden')
    // wn.classList.remove('first-change')
    frame.classList.remove('frame-one')
    document.querySelector('.shed-all-td').classList.remove('shed-all-td-null')
  } else {
    frame.classList.add('frame-hiden')
    //wn.classList.add('first-change')
    if (chk) {
      frame.classList.add('frame-one')
      document.querySelector('.shed-all-td').classList.add('shed-all-td-null')
    }
    if (framed != grp) {
      sendAjax('?frame=' + grp, function (ans) {
        framed = grp
        frame.innerHTML = ans
      })
    }
  }
}

// this to rewrite!
function show (val, node) {
  result = document.getElementsByClassName(node[0] /*"table-result"*/)
  see = document.getElementsByClassName(node[1] /*"table-see-r"*/)
  count = document.getElementsByClassName(node[2] /*"table-count"*/)
  if (result[val].style.display != 'block') {
    result[val].style.display = 'block'
    count[val].style.display = 'none'
    see[val].src = '/server/src/image/show_r.png'
  } else {
    result[val].style.display = 'none'
    count[val].style.display = 'inline'
    see[val].src = '/server/src/image/show_h.png'
  }
}

function validate (text) {
  text[0] = text[0].trim().match(/^\d{1,3}$/)
  text[1] = text[1].trim().match(/^[А-Я\d_]+$/i)
  text[2] = text[2].trim().match(/^[А-Я\d/\.()\s]+$/i)
  text[3] = text[3].trim().match(/^[\d]{3}[()\s]+[\d][)]$|^none$/i)
  text[4] = text[4].trim().match(/^[\d]$/)
  text[5] = text[5].trim().match(/^[\d]$/)
  text[6] = text[6].match(/^[\d]{1}$/)
  for (let i = 0; i < text.length; i++) {
    if (text[i] == null) {
      return i
    }
  }
  return text
}

//function filter () {
//  document.querySelector('.ops-all').classList.toggle('ops-all-change')
//document.querySelector('.first').classList.toggle('first-change')
//}

function edit_shed (val) {
  //let img = document.getElementsByClassName('shed-edit-img')
  document.body.classList.remove('loaded_hid')
  if (wind[val].classList.contains('editer-active')) {
    //img[val].classList.remove('shed-edit-img-active')
    wind[val].classList.remove('editer-active')
    console.log('remove')
  } else {
    if (val > wind.length - 3) {
      wind[val].style.transform = 'translate(0%, -100%)'
    }
    //img[val].classList.add('shed-edit-img-active')
    wind[val].classList.add('editer-active')
    console.log(val + wind[val])
  }
}

function rewrite (
  id = null,
  group = null,
  day = null,
  lesson = null,
  val = null,
  week = null,
  room = null
) {
  let days = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС']
  let rewriter = document.querySelector('.rewriter-back')
  shedId = id
  shedGroup = group
  if (rewriter.classList.contains('r-change')) {
    rewriter.classList.remove('r-change')
    document.querySelector('.next').classList.remove('first-change')
  } else {
    rewriter.classList.add('r-change')
    document.getElementById('r-name').innerHTML =
      '<b class="r-c-edit"> РЕДАКТИРОВАНИЕ </b><br>' +
      days[day - 1] +
      ', ' +
      lesson +
      ' пара: ' +
      val
    document.getElementById('name-text').innerHTML = val
    document.getElementById('room').innerHTML = room
    document.getElementById('select-one').value = lesson
    document.getElementById('select-two').value = week
    document.getElementById('select-day').value = day
  }
}

function change_db () {
  let out = [
    shedId,
    shedGroup,
    document.getElementById('name-text').innerHTML,
    document.getElementById('room').innerHTML,
    document.getElementById('select-one').value,
    document.getElementById('select-two').value,
    document.getElementById('select-day').value
  ]
  numb = validate([
    shedId || '1',
    shedGroup,
    document.getElementById('name-text').innerHTML,
    document.getElementById('room').innerHTML,
    document.getElementById('select-one').value,
    document.getElementById('select-two').value,
    document.getElementById('select-day').value
  ])
  if (numb.constructor !== Array) {
    document.querySelector('.r-er').innerHTML =
      'Проверьте правильность строки [' + out[numb] + ']'
  } else {
    document.querySelector('.r-er').innerHTML = null
    document.querySelector('.rewriter-rel').style.display = 'none'
    document.querySelector('.r-well').style.display = 'block'
    if (!shedId) {
      newtext =
        '?insert=' +
        1 +
        '&group=' +
        numb[1][0] +
        '&value=name="' +
        numb[2][0] +
        '", room="' +
        numb[3][0] +
        '", lesson_id="' +
        numb[4][0] +
        '", week_id="' +
        numb[5][0] +
        '", day_id="' +
        numb[6][0] +
        '"'
    } else {
      newtext =
        '?database=' +
        numb[0][0] +
        '&group=' +
        numb[1][0] +
        '&value=name="' +
        numb[2][0] +
        '", room="' +
        numb[3][0] +
        '", lesson_id="' +
        numb[4][0] +
        '", week_id="' +
        numb[5][0] +
        '", day_id="' +
        numb[6][0] +
        '"'
    }
    sendAjax(newtext, function () {})
    setTimeout(function () {
      document.body.classList.add('loaded_hid')
    }, 600)
    setTimeout(function () {
      document.getElementById('t-t-shed').classList.add('load-content')
      sendAjax('?menu=shed_inner&group=' + numb[1][0], function (ans) {
        document.getElementById('t-t-shed').innerHTML = ans
        document.getElementById('t-t-shed').classList.remove('load-content')
      })
      create()
    }, 1100)
  }
}

function del (group, id) {
  id = id.trim().match(/^\d{1,3}$/) || null
  group = group.trim().match(/^[А-Я\d_]+$/i) || null
  if (id !== null && group !== null) {
    document.getElementById('t-t-shed').classList.add('load-content')
    sendAjax('?delete=' + id + '&group=' + group, function (ans) {
      console.log(ans)
      sendAjax('?menu=shed_inner&group=' + group, function (ans) {
        document.getElementById('t-t-shed').innerHTML = ans
        document.getElementById('t-t-shed').classList.remove('load-content')
      })
    })
  } else {
    return
  }
}

function create (group = null) {
  let rewriter = document.querySelector('.rewriter-back')
  //let next = document.querySelector('.next')
  document.querySelector('.rewriter-rel').style.display = 'block'
  document.querySelector('.r-well').style.display = 'none'
  document.body.classList.remove('loaded_hid')
  document.querySelector('.r-er').innerHTML = null
  if (rewriter.classList.contains('r-change')) {
    rewriter.classList.remove('r-change')
    //next.classList.remove('first-change')
  } else {
    rewriter.classList.add('r-change')
    //next.classList.add('first-change')
    shedGroup = group
    shedId = null
    document.getElementById('r-name').innerHTML =
      '<b class="r-c-edit">Создание новой записи</b>'
    document.getElementById('name-text').innerHTML =
      'Например: 2н. Языки программирования 2 п/гр. Резниченко Ю.А. 338 (1)'
    document.getElementById('room').innerHTML = 'Например: 338(1)'
  }
}

//close some modal windows // change theme
window.onclick = function (event) {
  //let img = document.getElementsByClassName('shed-edit-img')
  let wind = document.getElementsByClassName('editer')

  if (opnM && event.target != document.querySelector('.hiden-bar')) {
    bar()
  }
  //if (event.target)
  if (event.target == document.querySelector('.rewriter-back')) {
    create()
  }

  /*for (var i = 0; i < wind.length; i++) {
    if (event.target != wind[i]) {
      //img[i].classList.remove('shed-edit-img-active')
      wind[i].classList.remove('editer-active')
    }
  }*/

  if (event.target == document.getElementById('theme')) {
    if (rel.getAttribute('href') == ' ') {
      rel.href = '/server/src/style/w-admin.css'
    } else {
      rel.href = ' '
    }
    sendAjax('?theme=1', function () {})
  }

  if (event.target.closest('.user')) {
    if (document.querySelector('.left').classList.contains('left-hiden')) {
      document.querySelector('.u-window').classList.toggle('u-w-active-o')
    } else {
      document.querySelector('.u-window').classList.toggle('u-w-active')
    }
    document.querySelector('.u-w-i-name').innerHTML = document.querySelector(
      '.left-icon'
    ).innerHTML
    document.querySelector('.w-u-n').value = document.querySelector(
      '.left-icon-name'
    ).innerHTML
  } else {
    if (event.target.closest('.u-window')) {
      // скрываем\отображаем блок с паролем
      if (event.target.closest('.w-u-n-i')) {
        document.querySelector('.u-i-psw').classList.toggle('u-i-psw-act')
      }
      // chpsw
      if (event.target.closest('#u-i-ch')) {
        if (
          !(oldPsw = document
            .querySelector('.c-p-old')
            .value.match(
              /^[A-Z\d!@#$%^&*()_{}\[\]\/\.\\<>\,~`|'";:]{10,}$/i
            )) ||
          !(newPsw = document
            .querySelector('.c-p-new')
            .value.match(/^[A-Z\d!@#$%^&*()_{}\[\]\/\.\\<>\,~`|'";:]{10,}$/i))
        ) {
          setTimeout(function () {
            document.querySelector('.w-u-err').innerHTML = null
          }, 2000)
          document.querySelector('.w-u-err').innerHTML =
            'Введите валидный пароль'
        } else {
          if (oldPsw != newPsw) {
            sendAjaxPost('chpsw=' + oldPsw, function (ans) {
              if (ans === '1') {
                sendAjaxPost('trupsw=' + newPsw, function (ans) {})
              } else {
                setTimeout(function () {
                  document.querySelector('.w-u-err').innerHTML = null
                }, 2000)
                document.querySelector('.w-u-err').innerHTML =
                  'Не удалось сменить пароль'
              }
            })
          }
        }
        document.querySelector('.u-i-psw').classList.toggle('u-i-psw-act')
        document.querySelector('.c-p-old').value = null
        document.querySelector('.c-p-new').value = null
      }

      // Изменение имени
      if (
        event.target.closest('.w-u-n-i-f') ||
        event.target.closest('.w-u-n-sv-a')
      ) {
        if (document.querySelector('.w-u-n').classList.contains('w-u-n-a')) {
          document.querySelector('.w-u-n').disabled = true
        } else {
          document.querySelector('.w-u-n').disabled = false
        }
        if (event.target.closest('.w-u-n-sv-a')) {
          if (document.querySelector('.w-u-n').value.trim() != user) {
            n_Nm = document.querySelector('.w-u-n').value.trim()
            //arr[0] = arr[0].match(/^[A-Z\d!@#$%^&*()_{}\[\]\/\.\\<>\,~`|'";:]{10,}$/i)
            if (!(n_Nm = n_Nm.match(/^[A-Z\d]{2,}$/i))) {
              setTimeout(function () {
                document.querySelector('.w-u-err').innerHTML = null
              }, 2000)
              document.querySelector('.w-u-err').innerHTML = 'Неверное имя'
            } else {
              sendAjaxPost('usr=1&n_name=' + n_Nm + '&old_n=' + user, function (
                ans
              ) {
                if (ans == 1) {
                  user = n_Nm
                  document.querySelectorAll(
                    '.left-icon-name'
                  )[0].innerHTML = n_Nm
                  document.querySelectorAll(
                    '.left-icon-name'
                  )[1].innerHTML = n_Nm
                  document.querySelector('.w-u-n').value = n_Nm
                } else {
                  setTimeout(function () {
                    document.querySelector('.w-u-err').innerHTML = null
                  }, 2000)
                  document.querySelector('.w-u-err').innerHTML =
                    'Не удалось изменить имя'
                }
              })
            }
          }
        }
        document.querySelector('.w-u-n').value = user
        document.querySelector('.w-u-n').classList.toggle('w-u-n-a')
        document.querySelector('.w-u-n-i-f').classList.toggle('w-u-n-i-f-a')
        document.querySelector('.w-u-n-sv').classList.toggle('w-u-n-sv-a')
      }
    } else {
      document.querySelector('.u-window').classList.remove('u-w-active')
      document.querySelector('.u-window').classList.remove('u-w-active-o')
    }
  }
}

// open needed page from menu
document.getElementById('l-m').onclick = function (event) {
  if (event.target == document.getElementById('l-m')) return
  if (selected) {
    selected.classList.remove('shed-edit-img-active')
  }
  selected = event.target.closest('.l-m-li')
  if (!selected) return
  document.getElementById('full-right').classList.add('load-content')
  selected.classList.add('shed-edit-img-active')
  sendAjax(selected.dataset.val, getMenu)
}

let slcLast = null
let trg = null
//cnt
document.getElementById('content').onclick = function (event) {
  if (event.target.closest('.params-img-all')) {
    document.querySelector('.editer-f').classList.toggle('editer-active')
  } else {
    if (document.querySelector('.editer-f'))
      document.querySelector('.editer-f').classList.remove('editer-active')
  }
  //
  if (event.target.closest('.s-s-filter')) {
    document.querySelector('.ops-all').classList.toggle('ops-all-change')
  } else {
    if (document.querySelector('.ops-all'))
      document.querySelector('.ops-all').classList.remove('ops-all-change')
  }
  // close all modal windows on page shed.
  /*if (!event.target.closest('.first')) {
    if (document.querySelector('.first')) {
      document.querySelector('.first').classList.remove('first-change')
      document.querySelector('.ops-all').classList.remove('ops-all-change')
    }
  }*/
  // open needed shed. on page sheudule
  if ((slc = event.target.closest('.ul-li'))) {
    if (slcLast) slcLast.classList.remove('ul-li-act')
    slcLast = slc
    slc.classList.add('ul-li-act')
    document.getElementById('t-t-shed').classList.add('load-content')
    document.getElementById('visible').style.display = 'none'
    sendAjax(slc.dataset.vl, function (ans) {
      document.getElementById('t-t-shed').innerHTML = ans
      document.querySelector('.shed-text').innerHTML =
        'Неделя ' + slc.dataset.vl.replace(/[A-Z_=?&]+/gi, ' ').trim()
      document.getElementById('t-t-shed').classList.remove('load-content')
    })
  }
  //}

  if (event.target.closest('.shed-name')) {
    if (trg) {
      trg.querySelector('.editer').classList.remove('editer-active')
      trg = null
      return
    } else {
      trg = event.target.closest('.shed-name')
      if (
        trg.dataset.val >
        document.getElementsByClassName('editer').length - 3
      )
        trg.querySelector('.editer').style.transform = 'translate(0%, -100%)'
    }
    trg.querySelector('.editer').classList.add('editer-active')
  } else {
    if (trg) {
      trg.querySelector('.editer').classList.remove('editer-active')
      trg = null
    }
  }

  //
  if (event.target.closest('.p-i-del-bd')) {
    sendAjax(
      '?deldb=' + event.target.closest('.p-i-del-bd').dataset.val,
      function (ans) {
        if (ans === '1') {
          document.getElementById('t-t-shed').classList.add('load-content')
          sendAjax(
            '?menu=shed_inner&chb=3&group=' +
              event.target.closest('.p-i-del-bd').dataset.val,
            function (ans) {
              document.getElementById('t-t-shed').innerHTML = ans
              document.querySelector('.shed-text').innerHTML =
                'Неделя 3 ' + event.target.closest('.p-i-del-bd').dataset.val
              document
                .getElementById('t-t-shed')
                .classList.remove('load-content')
            }
          )
        } else {
          last = document.getElementById('t-t-shed').innerHTML
          document.getElementById('t-t-shed').innerHTML =
            'Что-то пошло не так...'
          setTimeout(function () {
            document.getElementById('t-t-shed').innerHTML = last
          }, 4000)
        }
      }
    )
  }

  //
  if (event.target.closest('.convert')) {
    document.querySelector('.n-col').classList.add('load-content')
    sendAjax(
      '?convert=1&group=' + event.target.closest('.convert').dataset.val,
      function (ans) {
        document.querySelector('.n-col').classList.remove('load-content')
        if (ans == '1') {
          document.getElementById('t-t-shed').classList.add('load-content')
          sendAjax(
            '?menu=shed_inner&chb=3&group=' +
              event.target.closest('.convert').dataset.val,
            function (ans) {
              document.getElementById('t-t-shed').innerHTML = ans
              document.querySelector('.shed-text').innerHTML =
                'Неделя 3 ' + event.target.closest('.convert').dataset.val
              document
                .getElementById('t-t-shed')
                .classList.remove('load-content')
            }
          )
        } else {
          late = document.querySelector('.n-red').innerHTML
          document.querySelector('.n-red').style.color = 'red'
          document.querySelector('.n-red').innerHTML =
            'Не удалось конвертировать ' +
            event.target.closest('.convert').dataset.val
          setTimeout(function () {
            document.querySelector('.n-red').innerHTML = late
            document.querySelector('.n-red').style.color = 'inherit'
          }, 4000)
        }
      }
    )
  }

  // open needed page from main screen
  if (event.target.closest('.title-top')) {
    if (selected) {
      selected.classList.remove('shed-edit-img-active')
    }
    selected = document.getElementsByClassName('l-m-li')[
      event.target.closest('.title-top').dataset.val
    ] // 1 - result page
    document.getElementById('full-right').classList.add('load-content')
    selected.classList.add('shed-edit-img-active')
    sendAjax(selected.dataset.val, getMenu)
  }

  // change week
  //document.getElementById('prm-id').onclick = function (event) {
  let wk = event.target.closest('.option')
  if (wk) {
    document.getElementById('t-t-shed').classList.add('load-content')
    sendAjax(wk.dataset.vl, function (ans) {
      document.getElementById('t-t-shed').innerHTML = ans
      document.getElementsByClassName('shed-text')[0].innerHTML =
        'Неделя ' + wk.dataset.vl.replace(/[A-Z_=?&]+/gi, ' ').trim()
      document.getElementById('t-t-shed').classList.remove('load-content')
    })
    //console.log(wk.dataset.vl)
    // }
  }

  let sh = event.target.closest('.m-ul-li')
  if (sh) {
    if (selected) {
      selected.classList.remove('shed-edit-img-active')
    }
    selected = document.getElementsByClassName('l-m-li')[3] // 1 - result page
    document.getElementById('full-right').classList.add('load-content')
    selected.classList.add('shed-edit-img-active')
    sendAjax(selected.dataset.val, function (answ) {
      document.getElementById('content').innerHTML = answ
      sendAjax(sh.dataset.val, function (ans) {
        document.getElementById('t-t-shed').innerHTML = ans
        document.getElementsByClassName('shed-text')[0].innerHTML =
          'Неделя ' + sh.dataset.val.replace(/[A-Z_\/=?&]+/gi, ' ').trim()
        //document.getElementById('t-t-shed').classList.remove('load-content')
        document.getElementById('full-right').classList.remove('load-content')
      })
    })
  }

  //
  if (event.target == document.getElementById('shed-m')) {
    if (document.getElementById('visible').style.display != 'table-cell') {
      document.getElementById('visible').style.display = 'table-cell'
    } else {
      document.getElementById('visible').style.display = 'none'
    }
  }
}
let opnM = null
// show and hiden block menu
function bar () {
  leftT = document.getElementsByClassName('text')
  leftI = document.getElementsByClassName('l-m-img')
  if (document.querySelector('.left').classList.contains('left-hiden')) {
    opnM = null
    document.querySelector('.left').classList.remove('left-hiden')
    document.querySelector('.left-footer').classList.remove('left-footer-hiden')
    document.querySelector('.full-right').classList.remove('full-right-hiden')
    document.querySelector('.left-menu').classList.remove('left-menu-hiden')
    for (let i = 0; i < leftT.length; i++) {
      leftT[i].classList.remove('text-hiden')
      leftI[i].classList.remove('l-m-img-hiden')
    }
  } else {
    opnM = 1
    document.querySelector('.left').classList.add('left-hiden')
    document.querySelector('.left-menu').classList.add('left-menu-hiden')
    for (let i = 0; i < leftT.length; i++) {
      leftT[i].classList.add('text-hiden')
      leftI[i].classList.add('l-m-img-hiden')
    }
    document.querySelector('.left-footer').classList.add('left-footer-hiden')
    document.querySelector('.full-right').classList.add('full-right-hiden')
  }
}
function canvasStat (x, y, y1 = null, node) {
  //console.log(node)
  let width = node.offsetWidth
  let height = node.offsetHeight / 1.3
  let max = Math.max.apply(null, y)
  let min = Math.min.apply(null, y)
  let gip = 1
  if (height > 400) {
    gip = (height - 120) / max
  } else {
    gip = (height - 50) / max
  }
  let dx = width / 8
  let dy = height / 8
  let canvas = document.getElementById('canvas')
  let c = canvas.getContext('2d')
  let gradient = c.createLinearGradient(0, 0, width, height)
  gradient.addColorStop(0, '#123373')
  gradient.addColorStop(1, '#2dafff')
  canvas.height = height
  canvas.width = width
  if (width > 400) {
      c.font = '70px serif'
      c.lineWidth = 2.5
  } else {
      c.font = '40px serif'
      c.lineWidth = 1.0
  }
  c.fillStyle = '#fefefeef'
  c.strokeStyle = gradient
  c.beginPath()
  for (let i = 0; i < y.length; i++) {
    let dp = y[i]
    c.lineTo(i * dx + dx, height - dp * gip - dy)
    c.fillText('.', i * dx + dx - 10, height - dp * gip - dy + 3)
    c.stroke()
  }
  if (y1) {
    //c.lineWidth = 2.5
    gradient.addColorStop(0.1, '#5293e320')
    gradient.addColorStop(0.9, '#e352d2')
    c.strokeStyle = gradient
    c.beginPath()
    for (let i = 0; i < y1.length; i++) {
      let dp = y1[i]
      c.lineTo(i * dx + dx, height - dp * gip - dy)
      c.fillText('.', i * dx + dx - 10, height - dp * gip - dy + 3)
      c.stroke()
    }
  }
    if (width > 400) {
      c.font = '13px serif'
  } else {
      c.font = '9px serif'
  }
  c.fillStyle = '#aabaff9e'
  c.lineWidth = 0.1
  for (let i = 1; i < 8; i++) {
    c.fillText(Math.trunc((height - i * dy - dy) / gip), 0, i * dy)
    c.lineWidth = 0.1
    c.beginPath()
    c.moveTo(width, i * dy)
    c.lineTo(0, i * dy)
    c.moveTo(i * dx, height)
    c.lineTo(i * dx, 0)
    c.stroke()
  }
  c.lineWidth = 0.1
  for (let i = 0; i < x.length; i++) {
    let dp1 = y1[i]
    let dp = y[i]
    c.fillText(dp1, i * dx + dx - 7, height - dp1 * gip - dy - 10)
    c.fillText(dp, i * dx + dx - 7, height - dp * gip - dy - 10)
    c.fillText(x[i], i * dx + dx / 1.5, height - 5)
  }
}
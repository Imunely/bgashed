<?php

namespace Server\app;

/**
 * Методы для работы с расписанием
 */
class  File
{
    /**
     * Regular expressions to match the folowing context:
     * (for those who don't understand it)
     *
     * Any day of the week
     */
    private const LOADTO = '/server/files/';

    private const URL = 'https://bgarf.ru/obuchenie/raspisanie/';

    private const START = 'class="workarea-menu-detail-shedule">';

    private const LAST = '<span class="workarea-menu-title-desc">очной-заочной формы обучения<\span>';

    private const LINK = '/\/upload\/iblock\/[\w]*\/[А-Яа-я0-9 \.,()!-]*\.doc[x]{0,1}/ui';

    //private const LOAD = ''
    /**
     * Any day of the week
     */
    private const WEEKDAY = '/ПН|ВТ|СР|ЧТ|ПТ|СБ/ui';
    /**
     * Missing teacher's name at the end of the line
     */
    private const NOTNAME = '/[\d]{1,4}[\s]{0,1}[(][\d][)]{1,2}[\.]{0,1}$/u';
    /**
     *  Lack of classes
     */
    private const WINDOW = '/^[^-]*$/u';
    /**
     * Corresponds to physical education
     */
    private const STREET = '/ОЗ$|ФОК$/iu';
    /**
     * The string consists only of the teacher's name
     */
    private const IN_END = '/^[А-Яа-я]{5,30}[\s]{0,1}[А-Я]{1}[\.]{0,2}[А-Я]{1}[\.]{0,2}[\s]{0,1}[\d]{1,4}[\s]{0,1}[(][\d][)]{1,2}[\.]{0,1}$/u';
    /**
     * The line must end with the teacher's name
     */
    private const END = '/[А-Яа-я]{5,30}[\s]{0,1}[А-Я]{1}[\.]{0,2}[А-Я]{1}[\.]{0,2}[\s]{0,1}[\d]{1,4}[\s]{0,1}[(][\d][)]{1,2}[\.]{0,1}$/u';


    /**
     *  Matches the audience number in the end line
     */
    private const ROOM = '/[\d]{2,4}[\s]{0,1}[(]{1,2}[\d][)]{1,2}[\.]{0,1}$/u';
    /**
     * The line must start with the week number
     */
    private const F_WEEK = '/^1н./iu';
    private const S_WEEK = '/^2н./iu';

    /**
     * Все ссылки расписаний
     *
     * @var array
     */
    private $all_links = [];

    /**
     * Индекс для окна
     *
     * @var integer
     */
    public $typenone = 0;
    /**
     * Индекс для первой недели
     *
     * @var integer
     */
    public $typefirst = 50;
    /**
     * Индекс для второй недели
     *
     * @var integer
     */
    public $typesecond = 100;
    /**
     * Индекс для всех недель
     *
     * @var integer
     */
    public $typeall = 200;


    /**
     * Разбивает текстовых файл на массив
     *
     * @param string $filename
     * @return array
     */
    private function to_array(string $filename)
    {
        $numberclass = 'none';
        $day = 0;
        $postline = [];
        $raspisanie = [];
        if (!is_readable($filename)) {
            throw new \Exception("Файл [$filename] не существует или его невозможно прочесть");
        }
        $content = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($content as $line) {
            // убираю лишние пробелы //
            $line = trim(preg_replace('/\s+/', ' ', $line));
            // Просто запоминаю день недели //
            if (preg_match(self::WEEKDAY, $line, $dayend))
                $day = $dayend[0];
            // Пропускаю пустые строки, строки-точки //
            if (($line) != '' && ($line) != '.' && $day) {
                // Не забываю про номер занятия //
                if (preg_match('/^[\d]$/', $line)) $lesson = $line;
                else
                if (!preg_match(self::WEEKDAY, $line)) {
                    // строки не содержат в конце аудитории храним их временно в массиве
                    if (
                        !preg_match(self::STREET, $line)
                        &&
                        !preg_match(self::NOTNAME, $line)
                        &&
                        preg_match(self::WINDOW, $line)
                    ) {

                        $postline[] = $line;
                    } else {
                        // строка содержит только препода с аудиторией
                        if ($postline != null && preg_match(self::IN_END, $line, $fio)) {
                            foreach ($postline as $somelines) {
                                $needl[] = $somelines . ' ' . $fio[0];
                            }
                            $line = null;
                            $postline = null;
                        } else {
                            // строка содержит в конце препода с аудиторией
                            if ($postline != null && preg_match(self::END, $line, $fio)) {
                                $needl[] = $line;
                                foreach ($postline as $somelines) {
                                    $needl[] = $somelines . ' ' . $fio[0];
                                }
                                $postline = null;
                                $line = null;
                            }
                        }
                        if (!isset($postline)) {
                            if (isset($line)) $needl[] = $line;
                            foreach ($needl as $line) {
                                if (preg_match(self::ROOM, $line, $class)) {
                                    $numberclass = $class[0];
                                } else {
                                    $numberclass = 'none';
                                }
                                //!! тут костыль !!//
                                if (!isset($lesson)) $lesson = rand(10, 50);

                                if (!preg_match(self::WINDOW, $line)) {
                                    $raspisanie[$day][$lesson][$this->typenone][$numberclass] = '-Окно-';
                                } else
                                if (preg_match(self::F_WEEK, ($line))) {
                                    $raspisanie[$day][$lesson][$this->typefirst][$numberclass] = ($line);
                                    $this->typefirst++;
                                } else
                                if (preg_match(self::S_WEEK, ($line))) {
                                    $raspisanie[$day][$lesson][$this->typesecond][$numberclass] = ($line);
                                    $this->typesecond++;
                                } else
                                if (!preg_match('/Морозова$/i', $line)) {
                                    $raspisanie[$day][$lesson][$this->typeall][$numberclass] = ($line);
                                    $this->typeall++;
                                }
                            }
                            unset($needl);
                        }
                    }
                }
            }
        }
        unset($day, $line);
        //if (count($raspisanie) == 0) {
        //throw new \Exception("Не удалось найти полезную информацию в [$filename]");
        //}

        return $raspisanie;
    }


    /**
     *
     * @param string $filename
     * @return array
     */
    public function getRaspisanie(string $filename)
    {
        return $this->to_array($filename);
    }


    /**
     * Сканирует сайт и возвращает true если ссылки найдены, иначе false
     *
     * @return bool
     */
    private function file_link()
    {
        if (!($fp = fopen(self::URL, 'r'))) {
            unset($fp);
            throw new \Exception('Не удается подключиться к url: ' . self::URL);
        } else {
            $nm = [];
            $lnk = [];
            while (($line = fgets($fp)) !== false) {
                if (preg_match(self::LINK, $line)) {
                    preg_match(self::LINK, $line, $lnk[]);
                    $nm[] = preg_replace('/["\/\'=\sA-Z<>-]*/ui', '', preg_replace(self::LINK, '', $line));
                }
            }
            if (count($lnk) != count($nm)) throw new \Exception('Наименования не соотвествуют ссылкам');
            for ($i = 0; $i < count($lnk); $i++) {
                $this->all_links[$nm[$i]] = $lnk[$i][0];
            }
            unset($lnk, $nm);
        }
        return $this->all_links;
    }


    /**
     *
     * @return array
     */
    public function getLinks()
    {
        if (empty($this->all_links)) {
            if (false === $this->file_link()) {
                throw new \Exception(
                    'Кажется, на сайте нет ссылок! Либо проблемы с интернет подлючением'
                );
                exit;
            }
        }

        return $this->all_links;
    }


    /**
     * Копирует файлы указанные в ссылках
     *
     * @param array $fileLinks
     * @return array
     */
    private function copy_file(array $fileLinks)
    {
        $load = array();
        foreach ($fileLinks as $nm => $link) {
            $fileName = basename($link);
            $fileFrom = "https://bgarf.ru$link";
            $uploadToDir = trim($_SERVER['DOCUMENT_ROOT'] . self::LOADTO . $fileName);
            if (!copy(trim($fileFrom), $uploadToDir)) {
                throw new \Exception('Ошибка загрузки файла ' . $fileFrom . PHP_EOL);
                continue; //?
            } else {
                $load['pathload'][$nm] = $uploadToDir;
                $load['loaded'][$nm] = $fileLinks[$nm];
            }
        }
        unset($fileName, $fileFrom, $uploadToDir, $fileLinks);
        if (count($load) < 1) {
            throw new \Exception('Ни один файл не скачан');
            exit;
        }

        return $load;
    }


    /**
     *
     * @param array $filelinks
     * @return array
     */
    public function loadFile(array $filelinks)
    {
        return $this->copy_file($filelinks);
    }
}

<?php

namespace Server\app;

/**
 *          Конфигурирование
 *  System::getInstanse(path/to/file/.ini)
 */
class System
{

    /**
     *
     * @var string
     */
    private static $filename;

    /**
     *
     * @var array
     */
    private static $iniGet = array();

    /**
     *
     * @var float
     */
    private static $time = 0;


    /**
     * @param string $filename
     * @return string
     */
    public function setProp(string $filename)
    {
        if (file_exists($filename))
            self::$filename = trim($filename);
        else
            throw new \Exception('Указанный файл [' . $filename . '] не существует' . PHP_EOL);
    }


    /**
     * Аналогична функции ini_get
     *
     * @param string $key
     * @param string $section
     * @return string
     */
    public static function iniGet(string $key = null, string $section = null)
    {
        if (
            empty(self::$iniGet)
            &&
            false == (self::$iniGet = parse_ini_file(self::$filename, true, INI_SCANNER_TYPED))
        ) {
            throw new \Exception('Не удалось прочесть файл [' . self::$filename . ']');
        }
        if (isset($section) && isset($key)) return self::$iniGet[$section][$key];
        else if (isset($key)) return self::$iniGet[$key];
        else return self::$iniGet;
    }


    /**
     * Аналогична функции ini_set()
     *
     * @param string $key
     * @param string $value
     * @param string $section
     * @return void|bool
     */
    public static function iniSet(
        string $key,
        string $value,
        string $section = null
    ) {
        if (!isset($section)) {
            if (false !== ($line = file(self::$filename, FILE_IGNORE_NEW_LINES))) {
                $flag = count($line);
                for ($i = 0; $i < $flag; $i++) {
                    if (false !== strpos($line[$i], $key)) $line[$i] = $key . ' = ' . $value;
                }
            } else {
                throw new \Exception('Не удалось прочесть файл [' . self::$filename . ']');
            }
            if (!file_put_contents(self::$filename, implode("\n", $line))) {
                throw new \Exception('Не удалось записать в файл [' . self::$filename . ']');
            } else return true;
        }
    }


    /**
     * Запускает скрипт iniGet('demonURL')
     *
     * @return bool
     */
    private static function sockStart()
    {
        if (!($fp = fsockopen(
            $_SERVER['SERVER_NAME'],
            80,
            $errno,
            $errstr,
            30
        ))) {
            fclose($fp);
            unset($fp);
            throw new \Exception('Ошибка: ' . $errstr . ' [' . $errno . ']' . PHP_EOL);
        } else {
            $out = "GET http://" . $_SERVER['SERVER_NAME'] . self::iniGet('demonURL') . " HTTP/1.1\r\n";
            $out .= "Host: " . $_SERVER['SERVER_NAME'] . "\r\n";
            $out .= "Connection: Close\r\n\r\n";

            fwrite($fp, $out);
            fclose($fp);
            unset($fp);

            return true;
        }
    }


    /**
     * Определяет запущен ли демон
     *
     * @param boolean $flag
     * @return integer
     */
    public function status(bool $flag = false)
    {
        if ($flag) {
            if (self::iniGet('work') == 1) return 1;
            else return 0;
        }
        $time = trim(file_get_contents($_SERVER['DOCUMENT_ROOT'] . self::iniGet('log')));
        $life = 24 * 3600 / self::iniGet('iter') + 10;

        if (
            time() < strtotime($time) + $life
            &&
            self::iniGet('work') == 1
        ) return 1;
        else return 0;
    }


    /**
     * Запускает демон на выполнение
     *
     * @return boolean
     */
    public function run()
    {
        if ($this->status(true) == 0) {
            if (!self::iniSet('work', 1))
                throw new \Exception(
                    'Не удалось изменить параметр [work = '
                        . self::iniGet('work') . '] для запуска скрипта'
                );
            else {
                if (false == self::sockStart()) {
                    $this->stop();
                    throw new \Exception('Ошибка с запуском файла');
                } else {
                    return true;
                }
            }
        }

        return true;
    }


    /**
     * Останавливает демона
     *
     * @return boolean
     */
    public function stop()
    {
        if ($this->status(true) == 1) {
            if (!self::iniSet('work', 0))
                throw new \Exception(
                    'Не удалось изменить параметр work = '
                        . self::iniGet('work') . ' для остановки скрипта'
                );
            else
                return true;
        }
        return true;
    }


    /**
     * @param \Exception $err
     * @return void
     */
    public static function setErr(\Exception $err)
    {
        $text = "\n"  . date('Y-m-d H:i');
        $text .= PHP_EOL . $err->getMessage();
        $text .= PHP_EOL . $err->getTraceAsString();
        $text .= PHP_EOL;
        file_put_contents(
            $_SERVER['DOCUMENT_ROOT'] . self::iniGet('error'),
            $text,
            FILE_APPEND
        );
    }


    /**
     * @param string $f
     * @return void
     */
    public static function start(string $f = null)
    {
        self::$time = microtime(true);
    }


    /**
     * Регестрирует время работы начиная с System::start()
     * и записывает результат в time.txt
     *
     * @param array $msg
     * @param string $tp
     * @return void
     */
    public static function finish(array $msg, string $tp)
    {
        self::$time = microtime(true) - self::$time;
        $out = PHP_EOL . date('Y-m-d H:i');
        $out .= PHP_EOL . $tp . PHP_EOL . round(self::$time, 2);
        $out .= PHP_EOL . implode(PHP_EOL, $msg);
        $out .= "\n";
        if (!file_put_contents(
            $_SERVER['DOCUMENT_ROOT'] . self::iniGet('time'),
            $out,
            FILE_APPEND
        )) throw new \Exception('Не удалось записать результат работы сканера');
    }


    /**
     * Очищает файл лога от старых записей и возвращает массив актуальных
     *
     * @param string $file
     * @return array|int
     */
    private function clear(string $file)
    {
        $tofile = '';
        $life = $this->iniGet('life');

        if (false === ($line = file(
            $_SERVER['DOCUMENT_ROOT'] . self::iniGet($file),
            FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
        ))) throw new \Exception('Не удается прочеть файл ' . self::iniGet($file));

        if (!isset($line) || empty($line)) {
            return 0;
        }
        for ($j = 0, $i = 0; $i < count($line); $i++) {
            if (preg_match('/^\d{4}-/', $line[$i])) {
                $j++;
            }
            if ($j > 0) $update[$j][] = $line[$i];
        }
        unset($line);
        for ($j = 1; $j <= count($update); $j++) {
            if (strtotime($update[$j][0]) < (time() - $life)) {
                continue;
            }
            $tofile .= PHP_EOL . implode("\n", $update[$j]);
            $line[] = $update[$j];
        }
        file_put_contents($_SERVER['DOCUMENT_ROOT'] . self::iniGet($file), $tofile);
        unset($tofile, $file, $update, $life);
        if (!empty($line)) return $line;
        else return 0;
    }


    /**
     * Возвращает информацию с файла лога или файла ошибок
     *
     * @return array
     */
    public function msg(string $file)
    {
        try {
            return $this->clear($file);
        } catch (\Exception $e) {
            self::setErr($e);
            exit;
        }
    }
}

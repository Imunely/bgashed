<?php

namespace Server\app;

/**
 * Методы для работы с базой данных
 */
abstract class Dbase
{
    /**
     *
     * @var PDO
     */
    private static $pdo = null;

    /**
     *
     * @var Statement
     */
    private static $stm = null;

    private static $par = 'mysql:host=bga1086241.mysql; dbname=bga1086241_bga';
    private static $user = 'bga1086241_mysql';
    private static $pass = 'FxRu5O-J';

    /**
     * Выражение для создания таблицы Links
     */
    //const CREATELINKS = "CREATE TABLE Links (id INT NOT NULL, name text, tableN text)";

    /**
     * Общее выражение для создания таблиц-групп (ИБ-11)
     */
    const CREATESTANDART = " (id INT AUTO_INCREMENT PRIMARY KEY,
        day_id INT NOT NULL, lesson_id INT NOT NULL, week_id INT NOT NULL,
        room VARCHAR(10) NOT NULL, name TEXT(255))
    ";

    /**
     * Наименование таблицы с сылками
     */
    const TBL = 'Links';


    /**
     * Connect to database
     *
     * @return PDO
     */
    protected static function db()
    {
        if (!self::$pdo) {
            try {
                self::$pdo = new \PDO(
                    self::$par,
                    self::$user,
                    self::$pass,
                );
                self::$pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
                self::$pdo->exec('SET NAMES "utf8"');
            } catch (\Exception $e) {
                throw new \Exception("Не удается подключиться к базе данных\n" . $e);
                exit;
            }
        }

        return self::$pdo;
    }


    /**
     * Выполняет запрос к базе на изменение
     *
     * @param string $query
     * @param array $params
     * @return int|bool
     */
    public function set(string $query, array $params = null)
    {
        if (empty($query)) {
            throw new \Exception("Запрос не может быть пустым");
        } else {
            self::$stm = self::db()->prepare($query);
        }

        return (self::$stm->execute($params)) ? self::$stm->rowCount() : false;
    }


    /**
     * Выполняет запрос к базе на получение
     *
     * @param string $query
     * @param array $params
     * @return array,bool
     */
    public function get(string $query, array $params = null)
    {
        if (empty($query)) {
            throw new \Exception("Запрос не может быть пустым");
        } else {
            self::$stm = self::db()->prepare($query);
        }

        return (self::$stm->execute($params)) ? self::$stm->fetchAll(\PDO::FETCH_ASSOC) : false;
    }
}



class Update extends Dbase
{
    /**
     * Сравнивает ссылки в базе с ссылками на сайте
     *
     * @param array $now
     * @return array,false
     */
    public function link_diff(array $now, $tbl = self::TBL)
    {
        //return $now;
        if (empty($now) || !($db = $this->get_links($tbl))) {
            throw new \Exception('Массив не может быть пустым');
            unset($db);
            return false;
        } else {
            $exs['last'] = array_diff($db['link'], $now);
            $exs['new'] = array_diff($now, $db['link']);
            if (null != ($exs['last']) || null != ($exs['new'])) {
                // /upload/iblock/4cd/Расписание  Р -11  ОСЕНЬ 2021-22 уч. год.doc | Р21
                //return $exs;
                if (empty($exs['last'])) {
                    return ['add' => $exs['new']];
                }
                if (empty($exs['new'])) {
                    return ['delete' => $exs['last']];
                }
                //if (count($exs['last']) != count($exs['new'])) {
                //    return ['delete' => $exs['last'], 'add' => $exs['new']];
                //return  true;
                //}
                return ['delete' => $exs['last'], 'add' => $exs['new']]; //$exs;
                //$res['load'] = array_combine(array_keys($exs['last']), $exs['new']);
                //unset($exs, $db);
                //return $res;
            }

            return false;
        }
    }


    /**
     * Заменяет ссылки в базе на новые ссылки
     *
     * @param array|bool $newlinks
     * @return integer
     */
    public function updateLinks($newlinks, $tbl = self::TBL)
    {
        if (false === $newlinks) {
            throw new \Exception(
                "Обновлять нечего!
            Проверь все места работы функции diff()"
            );
            exit;
        }
        $row = 0;
        foreach ($newlinks as $tn => $name) {
            $sql = "UPDATE $tbl SET name=?, dt=? WHERE tableN=?";
            //$sql = 'UPDATE ' . $tbl . ' SET name = ? WHERE tableN = ?';
            $row += $this->set($sql, [$name, date('Y-m-d'), $tn]);
        }
        unset($sql, $newLinks);

        return $row;
    }


    /**
     * Заполняет таблицу Links ссылками
     *
     * @param array $params
     * @return integer
     */
    public function putLinks(array $params, string $tbl = SELF::TBL, bool $rst = true)
    {
        if ($rst) {
            if ($this->exist($tbl)) {
                $this->set('DROP TABLE ' . $tbl);
            }
            $this->set("CREATE TABLE $tbl (id INT AUTO_INCREMENT PRIMARY KEY, name text, tableN text, dt date)");
        }
        $row = 0;
        foreach ($params as $name => $link) {
            $sql = 'INSERT INTO ' . $tbl . ' SET name = ?, tableN = ?, dt = ?';
            //$table =  basename($name);
            $row += $this->set($sql, [$link, $name, date('Y-m-d')]);
        }

        return $row;
    }


    public function dayW(string $day)
    {
        $d_w = [
            'пн' => 1, 'вт' => 2, 'ср' => 3, 'чт' => 4, 'пт' => 5, 'сб' => 6, 'вс' => 7
        ];
        foreach ($d_w as $n_m => $d) {
            if (preg_match("/^$n_m$/iu", $day)) return $d;
        }
        return false;
    }


    /**
     * Создает таблицу $group и заполняет ее $params
     *
     * @param array $params
     * @param string $group
     * @return integer
     */
    public function putRaspisanie(array $params, string $group)
    {
        if ($this->exist($group)) {
            $this->set('DROP TABLE ' . $group);
        }
        $this->set("CREATE TABLE $group " . self::CREATESTANDART);
        $i = 0;
        $row = 0;
        foreach ($params as $day => $value1) {
            foreach ($value1 as $lesson => $value2) {
                foreach ($value2 as $week => $value3) {
                    if ($week >= 50 && $week < 100) $week = 1;  //??
                    else if ($week >= 100 && $week < 200) $week = 2;    //??
                    else $week = 0;
                    foreach ($value3 as $room => $name) {
                        $sql = "INSERT INTO $group SET day_id = ?, lesson_id = ?,
                        week_id = ?, room = ?, name = ?";
                        $row += $this->set($sql, [$this->dayW($day) ? $this->dayW($day) : ++$i, $lesson, $week, $room, $name]);
                    }
                }
            }
        }
        unset(
            $sql,
            $day,
            $value1,
            $value2,
            $week,
            $value3,
            $lesson,
            $room,
            $name,
            $d_w
        );

        return $row;
    }


    /**
     * Возвращает количество ссылок в таблице Links
     *
     * @return int
     */
    public function getCount()
    {
        if (false == ($links = $this->get('SELECT COUNT(*)FROM ' . self::TBL))) {
            throw new \Exception('Таблица ' . self::TBL . 'пуста');
            exit;
        }

        return $links[0]['COUNT(*)'];
    }


    /**
     * Возвращает массив данных с таблицы "Links"
     *
     * @return array,bool
     */
    public function get_links($tbl = self::TBL)
    {
        $result = $this->get('SELECT*FROM ' . $tbl);
        if (!$result) return false;
        $links = array();
        for ($i = 0; $i < count($result); $i++) {
            for ($j = 0; $j < count($result[$i]); $j++) {
                $links['link'][$result[$i]['id']] = $result[$i]['name'];
                $links['table'][$result[$i]['id']] = $result[$i]['tableN'];
                $links['dt'][$result[$i]['id']] = $result[$i]['dt'];
            }
        }
        unset($result);

        return $links;
    }


    public function delete_fromtb(array $id, string $tbl = SELF::TBL)
    {
        $sql = "DELETE FROM $tbl WHERE id=?";
        foreach ($id as $k => $vl) {
            if (!$this->set($sql, [intval($k)])) {
                throw new \Exception('Не удалось удалить строку с id=' . $k);
            }
        }
        return true;
    }


    /**
     * Проверяет существование таблицы
     *
     * @param string $table
     * @return boolean
     */
    public function exist(string $table)
    {
        if (!($lines = $this->get('SHOW TABLES'))) {
            throw new \Exception('Таблицы отсутсвуют в базе');
        } else {
            for ($i = 0; $i < count($lines); $i++) {
                foreach ($lines[$i] as $row) {
                    if (trim($row) == trim($table)) return true;
                }
            }
        }

        return false;
    }
}
//$cp = new Update();
//var_dump($cp->get_links('allLinks'));

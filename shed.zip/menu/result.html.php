
<!-- #Block1 -->
<div class="table">
    <div class="table-title">
        <img src="/server/src/image/scanR.png" width="25px" height="25px">
        <div> SCAN RESULT</div>
    </div>
    <?php
    if (!is_array($data = self::$app->msgScan())) {
        $this->html($data);
    } else {
    ?>
        <table class="table-table">
            <tr class="table-tr">
                <th class="table-th">
                    Последнее сканирование
                </th>
                <th class="table-th-sc">
                    Тип сканирования
                </th>
                <th class="table-th">
                    Затраченное время
                </th>
                <th class="table-th">
                    Обновлено файлов
                </th>
            </tr>
            <?php
            $data = self::$app->msgScan();
            $j = 0;
            for ($i = count($data) - 1; $i >= 0; $i--) {
            ?> <tr class="table-tr hov">
                    <td class="table-td">
                        <?php $this->html($data[$i][0]); ?>
                    </td>
                    <td class="table-td-sc">
                        <?php $this->html($data[$i][1]); ?>
                    </td>
                    <td class="table-td">
                        <?php $this->html($data[$i][2] . 'сек'); ?>
                    </td>
                    <?php
                    if (!(count($data[$i]) - 3)) {
                    ?>
                        <td class="table-td-r">
                            <div> Отсутсвует </div>
                        </td>
                    <?php
                    } else {
                    ?>
                        <td class="table-td">
                            <div class="c">
                                <?php $this->html(count($data[$i]) - 3); ?>
                            </div>
                            <div class="a">
                                <?php echo $this->result($data[$i]); ?>
                            </div>
                            <img src="/server/src/image/show_h.png" class="b" title="look!" onclick="show('<?php echo $j ?>',['a','b','c'])">
                        </td>
                    <?php
                        $j++;
                    }
                    ?>
                </tr>
            <?php
            }
            ?>
        </table>
    <?php
    }
    ?>
</div>
<!-- /#block1 -->

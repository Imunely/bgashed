<div class="table">
    <table class="shed-all">
        <td class="frame">
        </td>
        <td class="shed-all-td">
            <div class="shed-content">
                <div class="shed-inner">
                    <table class="table-table" id="t-t-shed">
                    </table>
                </div>
            </div>
        </td>

        <td id="visible">
            <div class="visible-header">
                Группа
            </div>
            <?php
            if (!($data = $this->db_links('allLinks'))) {
                $this->html('В базе пока нет ссылок');
                unset($data);
            } else { ?>
                <ul class="faq" id="f-ul">
                    <?php
                    $i = 0;
                    //$name = $data;
                    $data = $this->getFaculty($data['table']);
                    foreach ($data as $faq => $specAr) { ?>
                        <li class="faq-li" onclick="hiden_groups(<?= $i++ ?>, this)">
                            <span class="faq-text">
                                <?= $faq ?>
                            </span>
                            <img src="/server/src/image/from.png" class="faq-img" alt="Отобразить">
                            <ul class="shed-ul">
                                <?php
                                foreach ($specAr as $spec => $arName) { ?>
                                    <li class="ul-spec">
                                        <div class="u-s-table"> <?= $spec ?> </div>
                                        <?php foreach ($arName as $id => $nm) { ?>
                                            <div class="ul-li" data-vl="?menu=shed_inner&chb=3&group=<?= $nm ?>">
                                                <?php $this->html($nm) ?>
                                            </div>
                                        <?php } ?>
                                    </li>
                                <?php
                                }
                                ?>
                            </ul>
                        </li>
                    <?php
                    }
                    ?>
                </ul>
            <?php } ?>
        </td>

        <td id="group">
            <div class="left-title">
                <img src="/server/src/image/shed_m.png" id="shed-m" alt="Меню" title="Отобразить меню">
            </div>
            <div class="shed-left">
                <span class="shed-text">
                    Неделя 3
                    <?php $this->html($this->getGroup()) ?>
                </span>
            </div>
        </td>
    </table>

    <div class="rewriter-back">
        <div class="rewriter">
            <div class="rewriter-inner">
                <div id="r-name"></div>
                <img class="r-i-img" src="/server/src/image/chanel.png" title="Закрыть" onclick="create()">
                <img class="r-i-img l" src="/server/src/image/save.png" title="Сохранить" onclick="change_db('?database=')">
                <div class="r-er"></div>
            </div>
            <div class="r-well">
                <div class="r-w-inner">
                </div>
            </div>

            <fieldset class="rewriter-rel">
                <fieldset class="rewrite-name">
                    <legend> Наименование </legend>
                    <div contenteditable="true" id="name-text"> </div>
                </fieldset>

                <fieldset class="rewrite-name">
                    <legend> Аудиториия </legend>
                    <div contenteditable="true" id="room"> </div>
                </fieldset>

                <fieldset class="rewrite-name">
                    <legend> День недели </legend>
                    <select id="select-day">
                        <?php
                        for ($n = 1; $n < 8; $n++) { ?>
                            <option value="<?= $n ?>">
                                <?= $this->day[$n - 1] ?>
                            </option>
                        <?php
                        }
                        ?>
                    </select>
                </fieldset>

                <fieldset class="rewrite-name">
                    <legend> Номер занятия </legend>
                    <select id="select-one">
                        <?php
                        for ($n = 1; $n < 8; $n++) { ?>
                            <option value="<?= $n ?>">
                                <?= $n ?>
                            </option>
                        <?php
                        }
                        ?>
                    </select>
                </fieldset>

                <fieldset class="rewrite-name">
                    <legend> Номер недели </legend>
                    <select id="select-two">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="0">Все</option>
                    </select>
                </fieldset>

            </fieldset>
        </div>
    </div>
</div>

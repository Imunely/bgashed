
var doCache = true;


var CACHE_NAME = 'my-pwa-cache-v2';

// Очищает старый кэш
self.addEventListener('activate', event => {
    const cacheWhitelist = [CACHE_NAME];
    event.waitUntil(
        caches.keys()
            .then(keyList =>
                Promise.all(keyList.map(key => {
                    if (!cacheWhitelist.includes(key)) {
                        console.log('Deleting cache: ' + key)
                        return caches.delete(key);
                    }
                }))
            )
    );
});


self.addEventListener('install', function (event) {
    if (doCache) {
        event.waitUntil(
            caches.open(CACHE_NAME)
                .then(function (cache) {
                    // Получаем данные из манифеста 
                    fetch('/manifest.json')
                        .then(response => {
                            response.json()
                        })
                        .then(assets => {
                            // Открываем и кэшируем нужные страницы и файлы
                            const urlsToCache = ['/']
                            cache.addAll(urlsToCache)
                            console.log('cached');
                        })
                })
        );
    }
});

// fast hc
self.addEventListener('fetch', function (event) {
  if (event.request.method == 'POST') {
    return fetch(event.request)
  } else {
    event.respondWith(
      (async function () {
        try {
          var res = await fetch(event.request)
          var cache = await caches.open(CACHE_NAME)
          cache.put(event.request.url, res.clone())
          return res
        } catch (error) {
          return caches.match(event.request)
        }
      })()
    )
  }
})
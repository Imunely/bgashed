<tr class="table-tr-shed t-t-s-one">
    <?php
    if (!self::$app->tblExist(str_replace(',', '_', $this->getGroup()))) {
    ?><th class="n-col">
            <div class="n-red" style="font-weight:100; font-size: 150%;"> Для данного расписания режим редактирования недоступен</div>
            <div class="e-cont">
                <div class="e-inline">
                    <img src="/server/src/image/demo.png" class="params-img p-i-last p-i-lst" title="Посмотреть оригинал" onclick="frame('<?= $this->getLink() ?>', 1)">
                    <div style="font-size: 80%;font-weight:100;">Original</div>
                </div>
                <div class="e-inline">
                    <img src="/server/src/image/import.png" class="params-img p-i-last p-i-lst convert" data-val="<?= $this->getGroup() ?>" title="Конвертировать">
                    <div style="font-size: 80%; font-weight:100;">Convert</div>
                </div>
            </div>
        </th>
</tr>
<?php
    } else {
        $data = $this->get_shed(str_replace(',', '_', $this->getGroup()), $this->getWeek()); ?>
    <th class="table-th"> День</th>
    <th class="table-th"> Номер </th>
    <th class="table-th ops">
        Пара
        <div class="ops-all">
            <fieldset class="prm" id="prm-id">
                <legend>Сортировать по:</legend>
                <?php
                for ($l = 1; $l < 4; $l++) { ?>
                    <label class="option" data-vl="?menu=shed_inner&chb=<?= $l ?>&group=<?= $this->getGroup() ?>">
                        <?php if ($l == $this->getWeek()) { ?>
                            <input type="radio" class="option-input checkbox" checked name="exm" />
                        <?php } else { ?>
                            <input type="radio" class="option-input checkbox" name="exm" />
                        <?php } ?>
                        <div class="option-text">
                            <?= $this->weeksThr[$l - 1] ?>
                        </div>
                    </label>
                <?php
                } ?>
            </fieldset>
        </div>
        <img src="/server/src/image/shed_set.png" class="params-img-all" title="Параметры">
        <div class="editer-f">
            <div class="editer-inner">
                <ul class="shed-set">
                    <li class="s-s-li p-i-del-bd" data-val="<?= $this->getGroup() ?>">
                        <img src="/server/src/image/cleardata.png" class="params-img" title="Удалить с базы конвертированый вариант">
                        Удаление с базы
                    </li>
                    <li class="s-s-li" onclick="create('<?= str_replace(',', '_', $this->getGroup()) ?>')">
                        <img src="/server/src/image/add.png" class="params-img next" title="Добавить новую запись">
                        Новая запись
                    </li>
                    <li class="s-s-li s-s-filter">
                        <img src="/server/src/image/shed_p.png" class="params-img" title="Добавить фильтр">
                        Фильтр
                    </li>
                    <li class="s-s-li" onclick="frame('<?= $this->getLink() ?>')">
                        <img src="/server/src/image/demo.png" class="params-img" title="Посмотреть оригинал">
                        Оригинал
                    </li>
                </ul>
            </div>
        </div>
    </th>
    </tr>
    <?php
        $k = 0;
        foreach ($data as $i => $arr) {
            $col = count($arr); ?>
        <tbody class="day">
            <tr class="table-tr-shed">
                <td class="table-td" style="margin: 0; padding: 0;" rowspan="<?php echo $col + 1 ?>">
                    <?php $this->html($this->day[$i - 1]); ?>
                </td>
            </tr>
            <?php
            foreach ($arr as $lesson => $value) {
            ?>
                <tr class="table-tr-shed all">
                    <td class="table-td">
                        <?php echo $lesson; ?>
                    </td>
                    <td class="table-td" style="padding: 0; margin:0; border: none;">
                        <?php
                        foreach ($value as $week => $last) {
                            if ($week < 100) {
                                $week = 0;
                            } else if ($week < 200) {
                                $week = 1;
                            } else {
                                $week = 2;
                            }
                            foreach ($last as $room => $ls) {
                                foreach ($ls as $id => $val) { ?>
                                    <div class="shed-name" data-val="<?= $k ?>" alt="Изменить">
                                        <!--onclick="edit_shed( <?php //$k
                                                                ?>)"-->
                                        <span class="s-n-text" title="<?= $this->day[$i - 1] ?>, <?= $lesson ?> пара <?= $week ? '(' . $week . ')' : null ?>">
                                            <?php $this->html($val) ?>
                                        </span>
                                        <!--<img src="/server/src/image/shed_edit.png" class="shed-edit-img">-->
                                        <div class="editer">
                                            <div class="editer-inner">
                                                <ul class="inner-ul">
                                                    <li class="inner-li" onclick="rewrite('<?= $id ?>', '<?= str_replace(',', '_', $this->getGroup()) ?>','<?= $i ?>', '<?= $lesson ?>', '<?= $val ?>','<?= $week ?>', '<?= $room ?>')">
                                                        <img src="/server/src/image/shed_change.png" class="inner-img-shed">
                                                        Изменить
                                                    </li>
                                                    <li class="inner-li" onclick="del('<?= $this->getGroup() ?>', '<?= $id ?>')">
                                                        <img src="/server/src/image/trash.png" class="inner-img-shed">
                                                        Удалить
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                        <?php $k++;
                                }
                            }
                        }
                        ?>
                    </td>
                </tr>
            <?php
            }
            ?>
        </tbody>
<?php
        }
    }
?>

<!-- // -->
<fieldset class="main-inner tod-stat">
    <div class="t-s-content">
        <canvas id="canvas"></canvas>
    </div>
</fieldset>

<fieldset class="main-inner">
    <legend class="title-top" data-val="3">
        <img src="/server/src/image/chg.png" class="inner-img" alt="Изменено">
        <div class="t-p-inner">Последнее измененное расписание</div>
    </legend>
    <div class="inner-content">
        <table class="table-table">
            <tr class="table-tr">
                <th class="table-th">
                    Время
                </th>
                <th class="table-th">
                    Изменено
                </th>
                <th class="table-th">
                    Затраченное время (сек)
                </th>
            </tr>
            <?php
            $flag = true;
            if (is_array($data = self::$app->msgScan())) {
                for ($j = 0, $i = count($data) - 1; $i >= 0; $i--) {
                    if ((count($data[$i]) - 3)) {
                        $flag = false;
                        $j++;
                        if ($j > 10) break; ?>
                        <tr class="table-tr">
                            <td class="table-td">
                                <?php $this->html($data[$i][0]) ?>
                            </td>
                            <td class="table-td" id="t-m-ul">
                                <ul class="m-ul">
                                    <?php for ($g = 3; $g < count($data[$i]); $g++) { ?>
                                        <li class="m-ul-li" data-val="?menu=shed_inner&chb=3&group=<?= $data[$i][$g] ?>">
                                            <?= $data[$i][$g] ?>
                                        </li>
                                    <?php } ?>
                                </ul>
                            </td>
                            <td class="table-td t-t-time">
                                <?php $this->html($data[$i][2]) ?>
                            </td>
                        </tr>
                <?php }
                }
            }
            if ($flag) { ?>
                <tr class="table-tr">
                    <td class="table-td">
                        Изменения
                    </td>
                    <td class="table-td-r">
                        Отсутсвуют
                    </td>
                </tr>
            <?php
            }
            ?>
        </table>

    </div>
</fieldset>

<table id="m-i-inl">
    <!-- 2 -->
    <td class="m-i-inl-td">
        <fieldset class="main-inner inl m-i-i-f">
            <legend class="title-top" data-val="2">
                <img src="/server/src/image/error.png" class="inner-img" alt="Изменено">
                <div class="t-p-inner"> Последние ошибки</div>
            </legend>
            <div class="inner-content">
                <table class="table-table">
                    <tr class="table-tr">
                        <th class="table-th">
                            Время
                        </th>
                        <th class="table-th">
                            Ошибка
                        </th>
                    </tr>
                    <?php
                    if (is_array($data = self::$app->msgErr())) {
                        $data = self::$app->msgErr();
                        for ($j = 0, $i = count($data) - 1; isset($data[$i]); $i--, $j++) {
                            if ($j > 10) break; ?>
                            <tr class="table-tr">
                                <td class="table-td">
                                    <?php $this->html($data[$i][0]); ?>
                                </td>
                                <td class="table-td-r">
                                    <?php $this->html($data[$i][1]); ?>
                                </td>
                            </tr>
                        <?php }
                    } else { ?>
                        <tr class="table-tr">
                            <td class="table-td">
                                Ошибки
                            </td>
                            <td class="table-td-r">
                                Отсутсвуют
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                </table>
            </div>
        </fieldset>
    </td>
    <!-- 3 -->
    <td class="m-i-inl-td">
        <fieldset class="main-inner inl">
            <legend class="title-top" data-val="1">
                <img src="/server/src/image/scanR.png" class="inner-img" alt="Изменено">
                <div class="t-p-inner"> Недавнее сканирование</div>
            </legend>
            <div class="inner-content">
                <table class="table-table">
                    <tr class="table-tr">
                        <th class="table-th">
                            Время
                        </th>
                        <th class="table-th">
                            Обновленно
                        </th>
                    </tr>
                    <?php
                    if (is_array($data = self::$app->msgScan())) {
                        for ($j = 0, $i = count($data) - 1; isset($data[$i]); $i--, $j++) {
                            if ($j > 10) break; ?>
                            <tr class="table-tr">
                                <td class="table-td">
                                    <?php $this->html($data[$i][0]) ?>
                                </td>
                                <td class="table-td-r">
                                    <?php $this->html(count($data[$i]) - 3); ?>
                                </td>
                            </tr>
                        <?php }
                    } else { ?>
                        <tr class="table-tr">
                            <td class="table-td">
                                Обновления
                            </td>
                            <td class="table-td">
                                Отсутсвуют
                            </td>
                        </tr>
                    <?php } ?>
                </table>
            </div>
        </fieldset>
    <td>
</table>

<iframe id="orig" src="https://view.officeapps.live.com/op/embed.aspx?src=https://www.bgarf.ru<?= $this->getLink() ?>" frameBorder="0" scrolling="no">
    Пора обновить браузер!
</iframe>
<div class="f-full-back">
    <div id="f-close" title="Закрыть" onclick="frame(null)">
        <div id="f-c-inner">
        </div>
    </div>
    <b id="f-top">LOADING...</b>
</div>
<div class="brd"></div>

<!--
    Выводит все ошибки из файла
-->

<!-- #Block2 -->
<div class="table">
    <div class="table-title">
        <img src="/server/src/image/error.png" width="25px" height="25px">
        <div>ERRORS</div>
    </div>
    <?php
    if (!is_array($data = self::$app->msgErr())) {
        $this->html($data);
    } else {
    ?>
        <table class="table-table">
            <tr class="table-tr">
                <th class="table-th">
                    Время ошибки
                </th>
                <th class="table-th">
                    Содержание
                </th>
            </tr>
            <?php
            $data = self::$app->msgErr();
            $j = 0;
            for ($i = count($data) - 1; $i >= 0; $i--) {
            ?> <tr class="table-tr hov">
                    <td class="table-td">
                        <?php $this->html($data[$i][0]); ?>
                    </td>
                    <td class="table-td">
                        <div class="cc">
                            <?php $this->html($data[$i][1]) ?>
                        </div>
                        <div class="aa">
                            <?php $this->html($this->result($data[$i])); ?>
                        </div>
                        <img src="/server/src/image/show_h.png" class="bb" title="Посмотреть" onclick="show('<?php echo $j ?>',['aa','bb','cc'])">
                    </td>
                </tr>
            <?php
                $j++;
            }
            ?>
        </table>
    <?php
    }
    ?>
</div>
<!-- /#block2 -->

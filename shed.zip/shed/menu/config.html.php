<!--
    Выводит текущие конфигурационные настройки
-->

<div class="table">
    <div class="table-title">
        <div class="s-reset" title="Сброс данных базы"></div>
        <img src="/server/src/image/conf.png" width="25px" height="25px">
        <div>CONFIGURATION</div>
    </div>


    <div class="config">

        <fieldset class="p-f-inner">
            <legend>Статус сканера</legend>
            <?php if (self::$app->iniGet()['work']) { ?>
                <label id="lb-st" class="lb-on" for="checkbox"></label>
            <?php } else { ?>
                <label id="lb-st" class="lb-off" for="checkbox"></label>
            <?php } ?>
            <input type="checkbox" id="st-checkbox" />
        </fieldset>
        <fieldset class="c-path-file">
            <legend>Основные настройки</legend>
            <fieldset class="p-f-inner" id="p-f-iter">
                <legend>Количество сканирований в сутки</legend>
                <div class="v-value"><?= self::$app->iniGet()['iter'] ?></div>
                <input type="range" step="2" min="10" value="<?= self::$app->iniGet()['iter'] ?>" max="100">
            </fieldset>
            <fieldset class="p-f-inner">
                <legend>Время хранения результатов сканировани (В днях)</legend>
                <div class="v-value"><?= intdiv(self::$app->iniGet()['life'], (3600 * 24)) ?></div>
                <input type="range" step="1" min="2" value="<?= intdiv(self::$app->iniGet()['life'], (3600 * 24)) ?>" max="20">
            </fieldset>
        </fieldset>
        <fieldset class="c-path-file">
            <legend>Место конфигурационных файлов</legend>
            <fieldset class="p-f-inner">
                <legend>Файл конфигурации</legend>
                <div class="p-f-inner-text" contenteditable="true">
                    <?= self::$app->iniGet()['pathini'] ?>
                </div>
            </fieldset>
            <fieldset class="p-f-inner">
                <legend>Файл demon</legend>
                <div class="p-f-inner-text" contenteditable="false">
                    <?= self::$app->iniGet()['demonURL'] ?>
                </div>
            </fieldset>
            <fieldset class="p-f-inner">
                <legend>Файл запуска методов сканирования</legend>
                <div class="p-f-inner-text" contenteditable="false">
                    <?= self::$app->iniGet()['scanerURL'] ?>
                </div>
            </fieldset>
        </fieldset>
        <fieldset class="c-path-file">
            <legend>Место логирующих файлов</legend>
            <fieldset class="p-f-inner">
                <legend>Файл ошибок</legend>
                <div class="p-f-inner-text" contenteditable="false">
                    <?= self::$app->iniGet()['error'] ?>
                </div>
            </fieldset>
            <fieldset class="p-f-inner">
                <legend>Файл лога последней активности сканера</legend>
                <div class="p-f-inner-text" contenteditable="false">
                    <?= self::$app->iniGet()['log'] ?>
                </div>
            </fieldset>
            <fieldset class="p-f-inner">
                <legend>Файл результатов сканирования</legend>
                <div class="p-f-inner-text" contenteditable="false">
                    <?= self::$app->iniGet()['time'] ?>
                </div>
            </fieldset>
        </fieldset>


    </div>

</div>

<?php

/**
 * Определяет номер недели(1 или 2)
 *
 * @param string $start
 * @param integer $weeks
 * @return integer
 */
function week(string $start, int $weeks = 47)
{
    $date = new DateTime($start);
    $now = new DateTime();
    $nowDay = strtotime($now->format('Y-m-d'));
    for ($i = 1; $i < $weeks; $i++) {
        $firstday = strtotime($date->format('Y-m-d'));
        $lastday = strtotime($date->modify("+6 day")->format('d-m-Y'));
        if ($nowDay >= $firstday && $nowDay <= $lastday) {
            if ($i % 2) return 1;
            else return 2;
            //break;
        }
        $date->modify("+1 day");
    }
}

echo week('2020-09-01');

<?php

/**
 * Запускает скрипт [SCANER] в установленное количество раз iter(set.ini)
 * Проверить состояние можно в файле set.ini в параметре work;
 */


/**
 *
 * @param string $key
 * @param string $section
 * @return string
 */
function iniGet(string $key, string $section = null)
{
    $iniGet = array();
    if (empty($iniGet))
        $iniGet = parse_ini_file(
            $_SERVER['DOCUMENT_ROOT'] . '/server/include/config/set.ini',
            true,
            INI_SCANNER_TYPED
        );

    if (isset($section)) return $iniGet[$section][$key];
    else return $iniGet[$key];
}


$sleep = 3600 * 24 / iniGet('iter');

ini_set('memory_limit', '2M');
ini_set('max_execution_time', $sleep);
ignore_user_abort(1);
/**
 * Завершаем работу
 */
if (iniGet('work') == 0) exit;

/**
 * Логируемся
 */
if (false == file_put_contents(
    $_SERVER['DOCUMENT_ROOT'] . iniGet('log'),
    date('Y-m-d H:i') . PHP_EOL
)) {

    $out = '-' . date('Y-m-d H:i') . ': ' . $errstr($errno) . PHP_EOL;

    $out .= 'On the start [' . iniGet('scanerURL') . ']' . PHP_EOL;

    file_put_contents($_SERVER['DOCUMENT_ROOT'] . iniGet('error'), $out, FILE_APPEND);

    exit;
}

/**
 * Запускаем сканер
 */
if (false == ($fp = fsockopen(
    $_SERVER['SERVER_NAME'],
    80,
    $errno,
    $errstr,
    30
))) {

    $out = '[' . date('Y-m-d H:i') . '] : ' . $errstr . '(' . $errno . ')' . PHP_EOL;

    $out .= 'On the start [' . iniGet('scanerURL') . ']' . PHP_EOL;

    file_put_contents($_SERVER['DOCUMENT_ROOT'] . iniGet('error'), $out, FILE_APPEND);

    exit;
} else {

    $out = "GET http://" . $_SERVER['SERVER_NAME'] . iniGet('scanerURL') . " HTTP/1.1\r\n";

    $out .= "Host: " . $_SERVER['SERVER_NAME'] . "\r\n";

    $out .= "Connection: Close\r\n\r\n";

    fwrite($fp, $out);
}
fclose($fp);


sleep($sleep - 10);

/**
 * Запускаем себя вновь
 */
if (false == ($fp = fsockopen(
    $_SERVER['SERVER_NAME'],
    80,
    $errno,
    $errstr,
    30
))) {

    $out = '-' . date('Y-m-d H:i') . ': ' . $errstr($errno) . PHP_EOL;

    $out .= 'On the start [' . iniGet('demonURL') . ']' . PHP_EOL;

    file_put_contents($_SERVER['DOCUMENT_ROOT'] . iniGet('error'), $out, FILE_APPEND);

    exit;
} else {

    $out = "GET http://" . $_SERVER['SERVER_NAME'] . iniGet('demonURL') . " HTTP/1.1\r\n";

    $out .= "Host: " . $_SERVER['SERVER_NAME'] . "\r\n";

    $out .= "Connection: Close\r\n\r\n";

    fwrite($fp, $out);
}

fclose($fp);

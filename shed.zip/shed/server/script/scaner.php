<?php

/**
 * Точка вызова сканера
 */
 
if (!isset($_SERVER['DOCUMENT_ROOT']) || empty($_SERVER['DOCUMENT_ROOT']))
    $_SERVER['DOCUMENT_ROOT'] = '/home/bga1086241/bgashed.press/docs';
    
require_once $_SERVER['DOCUMENT_ROOT'] . '/vendor/autoload.php';

use Server\app\Application;

try {
    Application::getInstance()->update();
} catch (\Exception $e) {
    self::$ins[System::class]::setErr($e);
    exit;
}

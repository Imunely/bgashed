<?php

/**
 *     06/04/2021
 * Chasovskih Emmanyil
 *    IB31 bgarf
 */

namespace Server\app;

require_once $_SERVER['DOCUMENT_ROOT'] . '/vendor/autoload.php';

use Server\app\Doc;
use Server\app\System;
use Server\app\File;
use Server\app\Update;

/**
 * Общий класс управления серверной частью
 */
class Application
{
    /**
     *
     * @var array
     */
    private static $ins = [];

    /**
     *
     * @var array
     */
    private $all_links = null;

    /**
     *
     *
     * @var string
     */
    public $user = 'user';


    protected function __clone()
    {
    }


    public function __wakeup()
    {
        throw new \Exception("Cannot unserialize a Application.");
    }


    private function __construct()
    {
        self::$ins[System::class] = new System();
        self::$ins[Update::class] = new Update();
        self::$ins[File::class] = new File();
        self::$ins[Doc::class] = new Doc();
    }


    /**
     * Контролер создания класса Application (Singleton)
     *
     * @param string $path_ini
     * @return Application
     */
    public static function getInstance(string $path_ini = null): Application
    {
        if (!isset(self::$ins[static::class])) {
            self::$ins[static::class] = new static();
        }
        $path_ini ?: $path_ini = $_SERVER['DOCUMENT_ROOT'] . '/server/include/config/set.ini';
        self::define_ini($path_ini);

        return self::$ins[static::class];
    }


    /**
     * Устанавливает место файла конфигурации
     *
     * @param string $path_ini
     * @return void
     */
    private static function define_ini($path_ini)
    {
        try {
            self::$ins[System::class]->setProp($path_ini);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
        }
    }


    /**
     * Выводит в человеческом виде текст в браузер
     *
     * @param string|int $text
     * @param string $cod
     * @return string|int
     */
    public function htmlout($text, $cod = 'utf-8')
    {
        try {
            return htmlspecialchars(trim($text), ENT_QUOTES, $cod);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
        }
    }


    /**
     * Перезапись всех файлов в базе
     *
     * @param integer $count
     * @return bool
     */
    public function reset(int $count = null)
    {
        try {
            if (($all = $this->get_links())) {
                self::$ins[System::class]::start('Общий перезапуск');
                self::$ins[Update::class]->putLinks($all, 'allLinks');
                self::$ins[System::class]::finish(array_keys($all), 'Общий перезапуск');
            }
            /*
            if (empty($loaded)) {
                self::$ins[System::class]::start('Перезапуск');
                $slice = array_slice($this->get_links(), 0, $count ? $count : self::$ins[Update::class]->getCount());
                $loaded = self::$ins[File::class]->loadFile($slice);
            }
            //return $loaded;
            $loaded['pathload'] = $this->translate($loaded['pathload']);
            foreach ($loaded['pathload'] as $ad => $val) {
                $arr = self::$ins[File::class]->getRaspisanie($val);
                if (!isset($arr)) continue;
                //$group = preg_replace('/[-\s.txt,()]+/', '_', basename($loaded['pathload'][$i]));
                if (self::$ins[Update::class]->putRaspisanie($arr, $ad) >= 1) {
                    $loaded['dbloaded'][$ad] = $val;
                    //$loaded['group'][] = $group;
                    unlink($val);
                }
            }
            self::$ins[Update::class]->putLinks($loaded['dbloaded']);
            self::$ins[System::class]::finish($loaded['dbloaded'], 'Перезапуск');
            */
            //unset($arr, $group, $loaded);
            unset($all);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
            //exit;
        }

        return true;
    }


    /**
     * Обновляет записи в базе, если есть новые на сайте
     *
     * @return bool
     */
    public function update()
    {
        try {
            //$all = $this->get_links();
            /*$slice = array_slice(
                $this->get_links(),
                0,
                self::$ins[Update::class]->getCount()
            );*/
            //return ($df = self::$ins[Update::class]->link_diff($this->get_links(), 'allLinks'));
            /**
             * Завершаем работу
             */
            if ($this->iniGet('work') == 0) exit;
            /**
             * Логируемся
             */
            if (false == file_put_contents(
                $_SERVER['DOCUMENT_ROOT'] . $this->iniGet('log'),
                date('Y-m-d H:i') . PHP_EOL
            )) {
                $out = '-' . date('Y-m-d H:i') . ': Error'  . PHP_EOL;
                $out .= 'On the start [' . $this->iniGet('scanerURL') . ']' . PHP_EOL;
                file_put_contents($_SERVER['DOCUMENT_ROOT'] . $this->iniGet('error'), $out, FILE_APPEND);
                //exit;
            }
            // сканируем
            if (($df = self::$ins[Update::class]->link_diff($this->get_links(), 'allLinks')) !== false) {
                if (isset($df['delete'])) {
                    self::$ins[System::class]::start('Удалено');
                    self::$ins[Update::class]->delete_fromtb($df['delete'], 'allLinks');
                    self::$ins[System::class]::finish($df['delete'], 'Удалено');
                }
                if (isset($df['add'])) {
                    self::$ins[System::class]::start('Добавлено');
                    self::$ins[Update::class]->putLinks($df['add'], 'allLinks', false);
                    self::$ins[System::class]::finish(array_keys($df['add']), 'Добавдено');
                }
            } else {
                self::$ins[System::class]::start('Общее Обновление');
                self::$ins[System::class]::finish([null], 'Общее Обновление');
                exit;
            }
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
            exit;
        }

        return true;
    }


    /**
     * Конвертирует файл в текст
     *
     * @param array $file
     * @return int
     */
    public function convert(array $file)
    {
        try {
            self::$ins[System::class]::start('Конвертирование');
            $loaded = self::$ins[File::class]->loadFile($file);
            $loaded['pathload'] = $this->translate($loaded['pathload']);
            foreach ($loaded['pathload'] as $nm => $link) {
                $arr = self::$ins[File::class]->getRaspisanie($link);
                if (!isset($arr)) {
                    unlink($link);
                    continue;
                }
                if (self::$ins[Update::class]->putRaspisanie($arr, str_replace(',', '_', $nm))) {
                    $loaded['dbloaded'][$nm] = $loaded['loaded'][$nm];
                } else {
                    $this->deldb($nm);
                    //self::$ins[Update::class]->set('DROP TABLE ' . $nm);
                    unlink($link);
                    return 0;
                }
                unlink($link);
            }
            self::$ins[System::class]::finish(array_keys($loaded['dbloaded']), 'Конвертирование');
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
            exit;
        }
        return 1;
    }


    /**
     * Возращает расписание учебных групп
     *
     * @param string $group
     * @return array
     */
    public function get_shed(string $group, $where = 3)
    {
        switch ($where) {
            case '1':
                $where = "WHERE week_id != 2";
                break;
            case '2':
                $where = "WHERE week_id != 1";
                break;
            default:
                $where = null;
                break;
        }
        $query = "SELECT id, day_id, lesson_id, week_id, room, name FROM $group $where";
        try {
            return self::$ins[Update::class]->get($query);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
        }
    }


    public function accCont()
    {
        try {
            return self::$ins[Update::class]->get('SELECT COUNT(*)FROM ' . $this->user);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
        }
    }


    public function getPsw($user)
    {
        try {
            return self::$ins[Update::class]->get(
                "SELECT psw FROM " . $this->user .
                    " WHERE name='" . $user . "'"
            );
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
        }
    }
    /**
     * Удаляет запись в таблице
     *
     * @param string $group
     * @param integer $where
     * @return int|bool
     */
    public function delete_shed(string $group, int $where)
    {
        $sql = "DELETE FROM $group  WHERE id = $where";
        try {
            return self::$ins[Update::class]->set($sql);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
        }
    }


    /**
     * Добавляет запись в таблицу
     *
     * @param string $group
     * @param integer $where
     * @return int|bool
     */
    public function insert_shed(string $group, string $val)
    {
        $sql = "INSERT INTO $group SET $val";
        try {
            return self::$ins[Update::class]->set($sql);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
        }
    }


    /**
     * Обновляет ссылки в базе
     *
     * @param string $group
     * @param string $params
     * @param integer $where
     * @return int|bool
     */
    public function update_shed(string $group, string $params, int $where = null)
    {
        $sql = "UPDATE $group SET $params WHERE id = $where";
        try {
            return self::$ins[Update::class]->set($sql);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
        }
    }


    public function update_local(string $table, string $parms, $where)
    {
        $sql = "UPDATE $table SET $parms WHERE name=$where";
        try {
            return self::$ins[Update::class]->set($sql);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
        }
    }


    /**
     * Возвращает ссылки с сайта
     *
     * @return array
     */
    public function get_links()
    {
        if ($this->all_links === null) {
            $this->all_links = self::$ins[File::class]->getLinks();
        }

        return $this->all_links;
    }


    /**
     * Преобразует файл doc и возвращает txt
     *
     * @param array $doc
     * @return array
     */
    private function translate(array $doc)
    {
        $txt = array();
        foreach ($doc as $id => $file) {
            $txt[$id] = preg_replace('/\.doc[x]{0,1}$/', '.txt', $file);
            self::$ins[Doc::class]->read(trim($file));
            if (false !== file_put_contents($txt[$id], self::$ins[Doc::class]->parse())) {
                unlink($file);
            }
        }

        return $txt;
    }


    /**
     * Запускает скрипт demon
     *
     * @return void
     */
    public function startDemon()
    {
        try {
            //self::$ins[System::class]->run();
            $this->iniSet('work', 1);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
            exit;
        }
    }


    /**
     * Останавливает скрипт demon
     *
     * @return void
     */
    public function stopDemon()
    {
        try {
            //self::$ins[System::class]->stop();
            $this->iniSet('work', 0);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
            exit;
        }
    }



    /**
     * Определяет состояние Demon (запущен или нет)
     * $flag - если флаг установлен в TRUE, то проверяет без учета активности:
     * это не точная проверка состояния
     *
     * @param boolean $flag
     * @return integer
     */
    public function statusDemon(bool $flag = false)
    {
        try {
            return self::$ins[System::class]->status($flag);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
            exit;
        }
    }


    /**
     * Аналогична функции ini_get()
     *
     * @param string $key
     * @param string $section
     * @return string|array
     */
    public function iniGet(string $key = null, string $section = null)
    {
        try {
            return self::$ins[System::class]::iniGet($key, $section);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
            exit;
        }
    }


    /**
     * Аналогична функции ini_set
     *
     * @param string $key
     * @param string $value
     * @param string $section
     * @return void|bool
     */
    public function iniSet(
        string $key,
        string $value,
        string $section = null
    ) {
        try {
            return self::$ins[System::class]::iniSet($key, $value, $section);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
            exit;
        }
    }



    /**
     * Определяет номер недели(1 или 2)
     *
     * @param string $start
     * @param integer $weeks
     * @return integer
     */
    public function week(
        string $start = '2021-09-01',
        int $weeks = 147
    ) {
        $date = new \DateTime($start);
        $now = new \DateTime();
        $nowDay = strtotime($now->format('Y-m-d'));
        for ($i = 1; $i < $weeks; $i++) {
            $firstday = strtotime($date->format('Y-m-d'));
            $lastday = strtotime($date->modify("+6 day")->format('d-m-Y'));
            if ($nowDay >= $firstday && $nowDay <= $lastday) {
                if ($i % 2) return 1;
                else return 2;
                //break;
            }
            $date->modify("+1 day");
        }
        return 0;
    }

    /**
     * Возвращает лог ошибок
     *
     * @return array|string
     */
    public function msgErr()
    {
        if (($err = self::$ins[System::class]->msg('error')) == 0) {
            return 'Отсутсвуют актуальные ошибки';
        }

        return $err;
    }


    /**
     * Возвращает лог сканирования
     *
     * @return array|string
     */
    public function msgScan()
    {
        if (($scan = self::$ins[System::class]->msg('time')) == 0) {
            return 'Нет данных об актуальных изменениях';
        }

        return $scan;
    }


    /**
     * Возвращает ссылки всех распианий в базе
     *
     * @return array
     */
    public function db_links($tbl = 'Links')
    {
        try {
            return self::$ins[Update::class]->get_links($tbl);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
            exit;
        }
    }

    /**
     * Undocumented function
     *
     * @param string $ln
     * @return bool
     */
    public function deldb(string $ln)
    {
        try {
            if ($this->tblExist($ln))
                if (self::$ins[Update::class]->set('DROP TABLE ' . $ln) !== false)
                    return true;
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
            exit;
        }
    }
    
    
    public function setStat(string $wh)
    {
        $sql = 'INSERT INTO stat SET ' . $wh . ', dt="' .  date('Y-m-d') . '"';
        try {
            return self::$ins[Update::class]->set($sql);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
        }
    }

    public function getLastStat(string $wh, string $dt, string $eq = '=')
    {
        $sql = 'SELECT SUM(' . $wh . ') AS SUM FROM stat WHERE dt ' . $eq . '"' . $dt . '"';
        try {
            return self::$ins[Update::class]->get($sql);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
        }
    }

    /**
     * Undocumented function
     *
     * @param string $tbl
     * @return bool
     */
    public function tblExist(string $tbl)
    {
        try {
            return self::$ins[Update::class]->exist($tbl);
        } catch (\Exception $e) {
            self::$ins[System::class]::setErr($e);
            exit;
        }
    }
}
//echo '<pre>';
//print_r(Application::getInstance()->update());

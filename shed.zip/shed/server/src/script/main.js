let rqt = createRequestObject()
let activeWeek = document.querySelector('.m__subheading').innerHTML + gwd()
let rel = document.getElementById('themelink')
let bThm = '/server/src/style/app_b.css'
let frameLoaded = false
let lastTrgName = null
let frameContent = null
let interval = 30000
let activeGroup = null
let appContent = null
let iframeError = null
let navlistContent = null

function createRequestObject () {
  try {
    return new XMLHttpRequest()
  } catch (e) {
    try {
      return new ActiveXObject('Msxml2.XMLHTTP')
    } catch (e) {
      try {
        return new ActiveXObject('Microsoft.XMLHTTP')
      } catch (e) {
        return false
      }
    }
  }
}

function sendAjax (queryServer, callback, method = 'GET') {
  rqt.open(method, queryServer)
  rqt.onload = function () {
    if (rqt.status != 200) {
      console.log('Ошибка: ' + rqt.status + ':' + rqt.statusText)
    } else {
      if (typeof callback == 'function') callback(rqt.response)
    }
  }
  rqt.onerror = function () {
    console.log('Ошибка: ' + rqt.status + ':' + rqt.statusText)
    return false
  }
  rqt.send()
}

function sendAjaxPost (query, callback) {
  rqt.open('POST', ' ') // url = ' '
  rqt.setRequestHeader('Content-type', 'application/x-www-form-urlencoded')
  rqt.onload = function () {
    if (rqt.status != 200) {
      console.log('Ошибка: ' + rqt.status + ':' + rqt.statusText)
    } else {
      if (typeof callback == 'function') callback(rqt.response)
    }
  }
  rqt.send(query)
}

window.onload = function () {
  appContent = document.body.innerHTML
  setTimeout(function () {
    getStatus()
  }, 1000)
  document.body.classList.add('loaded_hiding')
  window.setTimeout(function () {
    document.body.classList.remove('loaded_hiding')
    document.body.classList.add('loaded')
  }, 300)
  let icn = document.getElementsByClassName('nav__list-li')
  for (let i = 0; i < icn.length; i++) {
    let gnm = icn[i].getElementsByClassName('g-n-b')
    for (let j = 0; j < gnm.length; j++) {
      if (gnm[j].classList.contains('is-active')) {
        icn[i].classList.add('is-active')
        break
      }
    }
  }
}

function getStatus () {
  sendAjaxPost('whoami=1', function (ans) {
     rel.href = JSON.parse(ans)[1]
    if (JSON.parse(ans)[0] === false) {
      document.querySelector('.m__subheading').innerHTML = '-очной формы-'
    } else {
      activeGroup = JSON.parse(ans)[0]
      document.querySelector('.m__dChange').classList.add('add__ched')
      document.querySelector('.m__subheading').innerHTML = '-очной формы-'
      document.querySelector('.m__dChange').innerHTML =
        'Посмотреть ' + JSON.parse(ans)[0]
      sendAjaxPost('fgroup=' + activeGroup, function (ans) {
        if ((frameContent = ans)) {
          document.querySelector('.content-hdn').innerHTML = frameContent
          statusFrame(document.getElementById('orig'), getNeedFrame)
        }
      })
    }
  })
}

function getNeedFrame () {
  //console.log('try again')
  document.querySelector('.content-hdn').innerHTML = frameContent
  document.getElementById('orig').classList.add('is-active')
  document.getElementById('f-close').classList.add('is-active')
  interval += 5000
  statusFrame(document.getElementById('orig'), getNeedFrame)
}

function statusFrame (selector, callback = null) {
  iframeError = setTimeout(function () {
    callback()
  }, interval)
  selector.onload = function () {
    try {
      this[0].contentDocument
      this[0].innerHTML
      this[0].document.innerHTML
    } catch (err) {
      clearTimeout(iframeError)
      setTimeout(function () {
        document.querySelector('.f-full-back').classList.add('is-active')
      }, 1500)
    }
    clearTimeout(iframeError)
    setTimeout(function () {
      document.querySelector('.f-full-back').classList.add('is-active')
    }, 1500)
  }
}

function slcTed (clc, selector) {
  if (clc.target.closest(selector)) return true
  else return false
}

document.body.onclick = function (event) {
  switch (true) {
    case slcTed(event, '#back'):
      document.body.innerHTML = appContent
      break
    case slcTed(event, '.i-i-s .btn'):
    case slcTed(event, '.i-i-f .btn'):
      document.querySelector('.container').classList.toggle('log-in')
      break
    case slcTed(event, '.to-adm'):
      sendAjaxPost('toAdm=1', function (ans) {
        if (JSON.parse(ans)[0] === true) {
          sendAjaxPost('varity=1', goToAdm)
        } else {
          sendAjaxPost('htAdm=1', function (ans) {
            document.body.innerHTML = ans
          })
        }
      })
      break
    case slcTed(event, '.container-form .btn'):
      if (
        !validForm([
          event.target.closest('.table-cell').querySelector('.i-psw').value,
          event.target.closest('.table-cell').querySelector('.i-nm').value
        ])
      ) {
        event.target.closest('.table-cell').querySelector('.i-psw').value = null
        event.target.closest('.table-cell').querySelector('.i-nm').value = null
        event.target.closest('.form-item').querySelector('.l-n-msg').innerHTML =
          'Bad password or username'
        setTimeout(function () {
          event.target
            .closest('.form-item')
            .querySelector('.l-n-msg').innerHTML = null
        }, 5000)
      } else {
        sendAjaxPost(
          event.target.closest('.container-form .btn').dataset.val.trim() +
            '&psw=' +
            event.target
              .closest('.table-cell')
              .querySelector('.i-psw')
              .value.trim() +
            '&name=' +
            event.target
              .closest('.table-cell')
              .querySelector('.i-nm')
              .value.trim(),
          function (ans) {
            if (ans === 'true') {
              document.querySelector('.container').classList.toggle('active')
              setTimeout(function () {
                document.querySelector('.container').classList.toggle('active')
                document.querySelector('.container').classList.toggle('log-in')
              }, 1500)
            } else if (ans === 'false') {
              event.target
                .closest('.table-cell')
                .querySelector('.i-psw').value = null
              event.target
                .closest('.table-cell')
                .querySelector('.i-nm').value = null
              event.target
                .closest('.form-item')
                .querySelector('.l-n-msg').innerHTML =
                'Bad password or username'
              setTimeout(function () {
                event.target
                  .closest('.form-item')
                  .querySelector('.l-n-msg').innerHTML = null
              }, 5000)
            } else {
              document.querySelector('.container').classList.toggle('active')
              setTimeout(function () {
                goToAdm(ans)
              }, 1000)
            }
          }
        )
      }
      break
    case slcTed(event, '.nav__trigger'):
      event.target.closest('.nav__trigger').classList.toggle('is-active')
      document.querySelector('.main').classList.toggle('is-active')
      document.querySelector('.main').classList.toggle('is-active-mob')
      break
    case slcTed(event, '.n-l-l-text'):
      navlistContent = document.querySelector('.nav__list').innerHTML
      event.target.closest('.n-l-l-text').classList.add('is-active')
      event.target
        .closest('.nav__list-li')
        .querySelector('.n-l-groups')
        .classList.add('is-active')
      document.querySelector('.nav__list').innerHTML = event.target.closest(
        '.nav__list-li'
      ).innerHTML
      document.querySelector('.nav__trigger').classList.add('is-back')
      document.querySelector('.nav__trigger__back').classList.add('is-active')
      document.querySelector('.main').classList.toggle('is-active-mob')
      break
    case slcTed(event, '.nav__trigger__back'):
      document.querySelector('.nav__list').innerHTML = navlistContent
      document.querySelector('.nav__trigger').classList.remove('is-back')
      document
        .querySelector('.nav__trigger__back')
        .classList.remove('is-active')
      break
    case slcTed(event, '.g-spec-name'):
      if (lastTrgName) {
        lastTrgName.classList.remove('is-active')
      }
      lastTrgName = event.target.closest('.g-spec').querySelector('.g-m-inner')
      event.target
        .closest('.g-spec')
        .querySelector('.g-m-inner')
        .classList.toggle('is-active')
      break
    case slcTed(event, '.g-name'):
      interval = 30000
      document.querySelector('.content').classList.add('is-active')
      document.querySelector('.m__dChange').classList.remove('add__ched')
      activeGroup = event.target
        .closest('.g-name')
        .dataset.val.replace(/[A-Z_=]+/gi, '')
      sendAjaxPost('fgroup=' + activeGroup, function (ans) {
        //console.log('Другая группа')
        if ((frameContent = ans)) {
          if (iframeError) clearTimeout(iframeError)
          document.querySelector('.content-hdn').innerHTML = null
          document.querySelector('.content-hdn').innerHTML = frameContent
          document.querySelector('.content-hdn').classList.add('is-active')
          document.getElementById('orig').classList.add('is-active')
          document.getElementById('f-close').classList.add('is-active')
          statusFrame(document.getElementById('orig'), getNeedFrame)
        }
      })
      document.querySelector('.m__dChange').innerHTML =
        'Изменено <strong>' +
        event.target.closest('.g-name').dataset.dt +
        '</strong>'
      document.querySelector('.m__heading').innerHTML =
        'Расписание ' + activeGroup
      document.querySelector('.m__subheading').innerHTML = activeWeek
      document.querySelector('.nav__list').innerHTML = navlistContent
      document.querySelector('.nav__trigger').classList.remove('is-back')
      document
        .querySelector('.nav__trigger__back')
        .classList.remove('is-active')
      document.querySelector('.nav__trigger').classList.remove('is-active')
      document.querySelector('.main').classList.remove('is-active')
      document.querySelector('.main').classList.remove('is-active-mob')
      break
    case slcTed(event, '.c-m-circ'):
      document.querySelector('.contact-me').classList.remove('is-active')
      document.querySelector('.c-m-inner').classList.remove('is-active')
      document.querySelector('.c-m-content').classList.remove('is-active')
      document.querySelector('.c-m-nm').classList.remove('is-active')
      break
    case slcTed(event, '.contact-me'):
      document.querySelector('.contact-me').classList.add('is-active')
      document.querySelector('.c-m-inner').classList.add('is-active')
      document.querySelector('.c-m-content').classList.add('is-active')
      document.querySelector('.c-m-nm').classList.add('is-active')
      break
    case slcTed(event, '.add__ched'):
      document.querySelector('.m__dChange').innerHTML =
        'Изменено <strong>' + getDate(activeGroup) + '<strong>'
      document.querySelector('.m__dChange').classList.remove('add__ched')
      document.querySelector('.content').classList.add('is-active')
      document.querySelector('.content-hdn').classList.add('is-active')
      document.getElementById('orig').classList.add('is-active')
      document.getElementById('f-close').classList.add('is-active')
      document.querySelector('.m__heading').innerHTML =
        'Расписание ' + activeGroup
      document.querySelector('.m__subheading').innerHTML = activeWeek
      break
     case slcTed(event, '.thm-app'):
      if (rel.getAttribute('href') != bThm) {
        rel.href = bThm
      } else {
        rel.href = ''
      }
      sendAjax('?theme=1', function () {})
      break
    default:
    //if (document.querySelector('.main').classList.contains('is-active')) {
        if (navlistContent)
          document.querySelector('.nav__list').innerHTML = navlistContent
        document.querySelector('.nav__trigger').classList.remove('is-back')
        document
          .querySelector('.nav__trigger__back')
          .classList.remove('is-active')
        document.querySelector('.nav__trigger').classList.remove('is-active')
        document.querySelector('.main').classList.remove('is-active')
      //}
      document.querySelector('.main').classList.remove('is-active-mob')
      if(document.querySelector('.contact-me').classList.contains('is-active')) {
          document.querySelector('.contact-me').classList.remove('is-active')
        document.querySelector('.c-m-inner').classList.remove('is-active')
        document.querySelector('.c-m-content').classList.remove('is-active')
        document.querySelector('.c-m-nm').classList.remove('is-active')
      }
      break
  }
}

function getDate (group) {
  allGrp = document.getElementsByClassName('g-name')
  for (let i = 0; i < allGrp.length; i++) {
    if (
      allGrp[i].dataset.val
        .replace(/[A-Z=]/gi, '', allGrp[i].dataset.val)
        .trim() === group.trim()
    ) {
      return allGrp[i].dataset.dt
    }
  }
  return 'в этом году'
}

function validForm (arr) {
  arr[0] = arr[0].match(/^[A-Z\d!@#$%^&*()_{}\[\]\/\.\\\,~`|'";:]{10,}$/i)
  arr[1] = arr[1].match(/^[A-Z\d]{2,}$/i)
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] == null) {
      return false
    }
  }
  return arr
}

function gwd () {
  let d = new Date()
  if (d.getDay() == 2) return '(Завтра смена недели)'
  else return ''
}

function goToAdm (ans) {
  if (ans) {
    document.body.classList.add('load-content')
    document.body.innerHTML = ans
    let s = document.createElement('script')
    let styl = document.createElement('link')
    styl.rel = 'stylesheet'
    s.src = '/server/src/script/admin.js'
    styl.href = '/server/src/style/b-admin.css'
    s.defer = true
    //styl.defer = true
    document.head.appendChild(styl)
    document.head.appendChild(s)
    s.onload = function () {
      selected.classList.add('shed-edit-img-active')
      sendAjax('?status=1', getStatusIter)
      onlineIs()
    }
  }
}
<div id="back" title="Вернуться на главную"></div>
<div class="container">
    <div class="container-relative">
        <div class="box"></div>
        <div class="container-forms">
            <div class="container-info">
                <div class="info-item i-i-f">
                    <div class="tablet">
                        <div class="table-cell">
                            <p>
                                Have an account?
                            </p>
                            <div class="btn">
                                Log in
                            </div>
                        </div>
                    </div>
                </div>
                <div class="info-item i-i-s">
                    <div class="tablet">
                        <div class="table-cell">
                            <p style="padding: 5px;">
                                To create an account, contact the administration
                            </p>
                            <p>
                            </p>
                            <div class="btn">
                                Sign up
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-form">
                <div class="form-item log-in">
                    <div class="l-n">LOGIN</div>
                    <div class="l-n-msg"></div>
                    <div class="tablet">
                        <div class="table-cell">
                            <input name="Username" class="i-nm" placeholder="Enter username" autocomplete="off" minlength="2" maxlength="6" type="text" />
                            <input name="Password" class="i-psw" placeholder="Enter password" autocomplete="off" type="Password" />
                            <div class="btn tt" data-val="login=1">
                                LOG IN
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-item sign-up">
                    <div class="l-n">SING UP</div>
                    <div class="l-n-msg"></div>
                    <div class="tablet">
                        <div class="table-cell">
                            <input name="Username" class="i-nm" placeholder="Username" autocomplete="off" minlength="2" maxlength="6" type="text" />
                            <input name="Password" class="i-psw" placeholder="Password" autocomplete="off" type="Password" />
                            <div class="btn tt" data-val="singup=1">
                                SING UP
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

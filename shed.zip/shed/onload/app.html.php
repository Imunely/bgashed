<!DOCTYPE html>
<html lang="ru">

<head>
    <title> FB </title>
    <meta charset="utf-8">
    <meta name="theme-color" content="#1c1f24" />
    <link rel="shortcut icon" href="/server/src/image/fb48.ico" />
    <link rel="icon" type="image/vnd.microsoft.icon" href="/server/src/image/fb48.ico">
    <link rel="stylesheet" href="/server/src/style/normalize.css">
    <link rel="stylesheet" href="/server/src/style/app.css">
    <!--    <link rel="stylesheet" href="/server/src/style/b-admin.css"> -->
    <link rel="stylesheet" href="/server/src/style/b-admin-enter.css">
    <link rel="stylesheet" id="themelink">
    <link rel="manifest" href="/manifest.json">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="/server/src/image/app/fb192.png">
</head>

<body>
    <!-- preloader -->
    <div class="back">
        <div class="circel">
            <div class="load"> Loading . . . </div>
            <div class="hands"></div>
            <div class="body"></div>
            <div class="head">
                <div class="eye"></div>
            </div>
        </div>
    </div>
    <!-- /preloader -->
    <div class="contact-me">
        <div class="c-m-inner">
            <img class="c-m-nm" src="/server/src/image/c-me.png">
            <div class="c-m-content">
                <div class="c-m-title">
                    <div class="c-m-photo">
                        <img src="/server/src/image/me.png" class="c-m-img to-adm">
                    </div>
                    <div class="c-m-about">
                        <strong class="c-m-lff">Emmanyil Chasovskih</strong> <br>
                        Hi, I'm a web developer. For questions, please contact me.
                    </div>
                </div>
                <div class="c-m-bottom">
                    CONTACT ME
                    <div class="c-m-circ"></div>
                </div>

                <a href="mailto:milkimynely@gmail.com" class="c-m-src c-gmail">
                    <img src="/server/src/image/gmail.png" class="c-img">
                    <div class="c-content">
                        <h4 class="c-lnk">Email</h4>
                        <span class="sp">milkimynely@gmail.com</span>
                    </div>
                </a>
                <a href="https://vk.com/yourmules" class="c-m-src c-vk">
                    <img src="/server/src/image/vk.png" class="c-img">
                    <div class="c-content">
                        <h4 class="c-lnk">Vkontakte</h4>
                        <span class="sp">@yourmules</span>
                    </div>
                </a>
                <a href="tg://resolve?domain=imunelyDev" class="c-m-src c-tg">
                    <img src="/server/src/image/tg.png" class="c-img">
                    <div class="c-content">
                        <h4 class="c-lnk">Telegram</h4>
                        <span class="sp">@imunelyDev</span>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <!-- main -->
    <div class="nav__bar">
        <div class="nav__trigger">
            <div class="bars"></div>
        </div>
        <div class="nav__trigger__back">
            <div class="bars"></div>
        </div>
        <img src="/server/src/image/admin.png" title="Go to admin" alt="admin" class="n-b-admin to-adm">
    </div>

    <main class="main">
        <section class="m-title">
            <div class="m__content">
                <h1 class="m__heading"> Расписание БГАРФ</h1>
                <h4 class="m__subheading">
                <?php 
                if (self::$app->week() != 0) {
                    $this->html('Неделя '.self::$app->week()); 
                } else {
                    echo 'Первая неделя с 2021-09-01';
                }
                ?> </h4>
                <h5 class="m__dChange"></h5>
            </div>
        </section>
        <section class="content">
          <!--<div class="app-nws" style="border-left: 5px solid red; padding: 10px; color: black; margin-top: 10px"><strong>Внимание!</strong> <br>27-09-2021 (понедельник) в период 01:00-22:00 сервис будет недоступен. Приносим извинения :(</div>
           -->
           <div class="thm-app"></div>
            <h4> Почему смотреть расписание здесь — правильный выбор?</h4>
            <p class="c-text">
                Так как в расписание занятий периодически вносятся изменения, <strong>ТЕПЕРЬ</strong>
                нет необходимости <strong>скачивать файл, искать календарь для определения недели(1/2), а затем анализировать на поправки в файле!</strong>
            </p>
            <p class="c-text">Расписание отображается непосредственно в <strong>окне браузера</strong>, активная <strong>неделя расположена</strong> над расписанием, последнее обновление датируется и помечается знаком (!)</p>
            <h4>Просим Вас обратить внимание на обозначения аудиторий Академии:</h4>
            <ul class="push">
                <li class="push-li">1 – учебный корпус №1, ул. Молодёжная, 6 </li>
                <li class="push-li">2 – учебный корпус №2, ул. Озёрная, 30</li>
                <li class="push-li">5 – учебный корпус №5, ул. Островского, 22</li>
                <li class="push-li">ОЗ – основной спортивный зал, ул.Молодёжная, 3-А </li>
                <li class="push-li">ФОК – физкультурный оздоровительный комплекс, ул.Островского, 4</li>
                <li class="push-li">Д – проведение занятий в виде видеоконференцсвязи с использованием дистанционных образовательных технологий (ДОТ).</li>
            </ul>
        </section>
        <div class="content-hdn"></div>
    </main>

    <nav class="nav">
        <?php
        if (!($data = $this->db_links('allLinks'))) {
            $this->html('В базе пока нет ссылок');
            unset($data);
        } else { ?>
            <ul class="nav__list">
                <?php
                $i = 0;
                //$name = $data;

               $fq = ['РТФ' => 'rtf', 'СВФ' => 'svf', 'ТФ' => 'tf', 'СМФ' => 'smf'];
                    $data = $this->getFaculty($data['table']);
                    foreach ($data as $faq => $specAr) { ?>
                        <li class="nav__list-li <?= $fq[trim($faq)] ?>">
                        <span class="n-l-l-text">
                            <?= $faq ?>
                        </span>
                        <ul class="n-l-groups">
                            <?php
                            foreach ($specAr as $spec => $arName) { ?>
                                <li class="g-spec">
                                    <div class="g-spec-name"> <?= $spec ?> </div>
                                    <div class="g-m-inner">
                                        <?php foreach ($arName as $id => $nm) {
                                            $dys = (time() - strtotime($this->getDate($id))) / (60 * 60 * 24);
                                            if ($dys < 3) {
                                                $nw = ' is-active';
                                            } else {
                                                $nw = null;
                                            }  ?>
                                            <div class="g-name" data-dt="<?= $this->getDate($id) ?>" data-val="fgroup=<?= $nm ?>">
                                                    <b class="g-n-b <?= $nw ? $nw : null ?>"><?php $this->html(preg_replace('/[А-Я]/ui', '', $nm)) ?></b>
                                            </div>
                                        <?php } ?>
                                    </div>
                                </li>
                            <?php
                            }
                            ?>
                        </ul>
                    </li>
                <?php
                }
                ?>

            <?php } ?>
            </ul>
    </nav>
    <script src="/server/src/script/main.js" defer> </script>

    <!-- <div class="app">
      Here raspisanie
        <div class="to-adm">
            Перейти к адм.
        </div>
    </div>-->
    <!-- /main -->
</body>

<script>
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function() {
            navigator.serviceWorker.register('../service-worker.js').then(function(registration) {
                console.log('ServiceWorker registration successful with scope: ', registration.scope);
            }, function(err) {
                console.log('ServiceWorker registration failed: ', err);
            }).catch(function(err) {
                console.log(err)
            });
        });
    } else {
        console.log('service worker is not supported');
    }
</script>

</html>

<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/vendor/autoload.php';

use  Server\app\Application;

/**
 * Контролер управления администраторской частью
 */
class Admin
{

    /**
     * Хранит экземпляр класса Application
     *
     * @var Application
     */
    private static $app;

    /**
     * Хранит экземппляр класса Admin
     *
     * @var Admin
     */
    private static $adm;

    //private $keywords = ['/[А-Я]{1,2,3}[\d]{1,2}/u'];

    private $group = null;

    private $a_week;
    
    private $stat = null;

    private $grp;

    private $links = null;

    private $day = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'];

    private $weeksThr = ['1н.', '2н.', 'Все'];

    // private $checked = [2 => 'checked'];

    private function __construct(Application $app)
    {
        self::$app = $app;
    }



    /**
     * Контролер создания экземпляра класса  Admin
     *
     * @return Admin
     */
    public static function getAdmin()
    {
        if (!isset(self::$adm)) {
            self::$adm = new static(Application::getInstance());
        }

        return self::$adm;
    }



    /**
     * Создает "куки" если они отсуствуют
     *
     * @return string
     */
    private function empty_cookie()
    {
        if (!isset($_COOKIE["theme"])) {
            setcookie("theme", ' ', time() + 60 * 60 * 24 * 30);
            return ' ';
        }
        return $_COOKIE["theme"];
    }


    private function cookie_group()
    {
        if (!isset($_COOKIE["group"])) {
            setcookie("group", false, time() + 60 * 60 * 24 * 30);
            $this->setStat('NU=1');
            return false;
        } else {
            $this->setStat('LU=1');
        }
        return $_COOKIE["group"];
    }

    public function validate()
    {
        if (isset($_SESSION['ent']) && $_SESSION['ent'] === 1) {
            return json_encode([$_SESSION['entered']]);
        } else {
            return json_encode([false]);
        }
    }

    public function varity()
    {
        if (isset($_SESSION['ent']) && $_SESSION['ent'] === 1 && $_SESSION['entered'] === true) {
            return $this->add_content('adm');
        }
    }

    public function checkForm()
    {
        switch (array_key_first($_POST)) {
            case 'login':
                if (isset($_POST['psw']) && isset($_POST['name']) && null != (self::$app->getPsw(trim($_POST['name'])))) {

                    if (
                        password_verify(
                            trim($_POST['psw']),
                            self::$app->getPsw(trim($_POST['name']))[0]['psw']
                        )
                    ) {
                        $_SESSION['ent'] = 1;
                        $_SESSION['entered'] = true;
                        $_SESSION['name'] = trim($_POST['name']);
                        return $this->add_content('adm');
                    } else {
                        return json_encode(false);
                    }
                } else {
                    return json_encode(false);
                }
                break;

            case 'singup':
                if (self::$app->accCont()[0]['COUNT(*)'] >= 2) {
                    return json_encode(false);
                }
                if (isset($_POST['psw']) && isset($_POST['name'])) {
                    if (self::$app->insert_shed(
                        self::$app->user,
                        "name='" . trim($_POST['name']) . "', psw='" .
                            password_hash(trim($_POST['psw']), PASSWORD_DEFAULT) . "'"
                    ) === 1)
                        return json_encode(true);
                    else json_encode(false);
                } else {
                    json_encode(false);
                }
                break;
            default:
                break;
        }
    }

    public function getDate(int $id)
    {
        foreach ($this->db_links()['dt'] as $dId => $vl) {
            if ($id == $dId) {
                return $vl;
            }
        }
    }

    private function updt_nm($table, $parms, $where)
    {
        if (self::$app->update_local($table, 'name="' . $parms . '"', '"' . $where . '"')) {
            $_SESSION['name'] = $parms;
            return 1;
        }
        return 0;
    }
    /**
     * Контролер действий на стороне клиента
     *
     * @return void
     */
    public function listen()
    {
        if (
            isset($_SESSION['ent']) &&
            isset($_SESSION['entered']) &&
            $_SESSION['ent'] === 1 &&
            $_SESSION['entered'] === true
        ) {
        switch (array_key_first($_GET)) {
            case 'status':
                echo json_encode(
                    [
                        self::$app->statusDemon(),
                        file_get_contents($_SERVER['DOCUMENT_ROOT'] . self::$app->iniGet('log')),
                        $this->empty_cookie(),
                        $_SESSION['name']
                    ]
                );
                exit;
                break;
            case 'cng':
                echo json_encode(
                    [
                        $this->changeStatus(),
                        file_get_contents($_SERVER['DOCUMENT_ROOT'] . self::$app->iniGet('log'))
                    ]
                );
                exit;
                break;
            case 'menu':
                echo $this->add_content($_GET['menu']);
                exit;
                break;
            case 'theme':
                //echo $this->setTheme();
                exit;
                break;
            case 'save':
                echo $this->addconfig(
                    trim($_GET['save']),
                    trim($_GET['vll'])
                );
                exit;
                break;
            case 'main':
                echo $this->add_content('main');
                exit;
                break;
            case 'database':
                $this->update_db($_GET['group'], $_GET['value'], $_GET['database']);
                exit;
            case 'insert':
                $this->insert_db($_GET['group'], $_GET['value']);
                exit;
            case 'delete':
                $this->delete_db($_GET['group'], $_GET['delete']);
                exit;
            case 'frame':
                echo $this->add_content('frame');
                exit;
            case 'convert':
                echo self::$app->convert([$this->getGroup() => $this->getLink()]);
                exit;
                break;
            case 'deldb':
                echo self::$app->deldb($_GET['deldb']);
                exit;
                break;
            case 'canvas':
                echo json_encode([
                    array_keys($this->getLastStat()['NU']),
                    array_values($this->getLastStat()['LU']),
                    array_values($this->getLastStat()['NU'])
                ]);
                exit;
                break;
            default:
                break;
                exit;
        }
        }
        switch (array_key_first($_POST)) {
            case 'trupsw':
                echo $this->chPsw(self::$app->user, $_POST['trupsw']);
                exit;
                break;
            case 'toAdm':
                echo $this->validate();
                exit;
                break;
            case 'varity':
                echo $this->varity();
                exit;
                break;
            case 'htAdm':
                echo $this->add_content('toAdm');
                exit;
                break;
            case 'login':
            case 'singup':
                echo $this->checkForm();
                exit;
                break;
            case 'chpsw':
                echo $this->isTruePsw($_POST['chpsw']);
                exit;
                break;
            case 'usr':
                echo $this->updt_nm(self::$app->user, $_POST['n_name'], $_POST['old_n']);
                exit;
                break;
            case 'fgroup':
                $this->group = $_POST['fgroup'];
                setcookie("group", $_POST['fgroup'], time() + 60 * 60 * 24 * 30);
                echo $this->add_content('frame');
                exit;
                break;
            case 'whoami':
                echo json_encode([$this->cookie_group(), $this->empty_cookie()]);
                exit;
                break;
            default:
                break;
        }
        //echo 'Hello!';
        include_once $_SERVER['DOCUMENT_ROOT'] . '/onload/app.html.php';
    }

    private function isTruePsw(string $psw)
    {
        if (
            password_verify(
                trim($psw),
                self::$app->getPsw(trim($_SESSION['name']))[0]['psw']
            )
        ) {
            $_SESSION['trpsw'] = true;
            return 1;
        } else {
            return 0;
        }
    }


    private function chPsw(string $table, string $psw)
    {
        if (
            isset($_SESSION['trpsw']) &&
            $_SESSION['trpsw'] === true &&
            self::$app->update_local(
                $table,
                'psw="' . password_hash(trim($psw), PASSWORD_DEFAULT) . '"',
                '"' . $_SESSION['name'] . '"'
            )
        ) {
            return 1;
        }
        return 0;
    }


    private function setTheme()
    {
        if ($_COOKIE['theme'] == "/server/src/style/app_b.css") {
            $theme = '';
            setcookie("theme", $theme, time() + 60 * 60 * 24 * 30);
        } else {
            $theme = "/server/src/style/app_b.css";
            setcookie("theme", $theme, time() + 60 * 60 * 24 * 30);
        }
        return $theme;
    }


    /**
     * Котролер полученного контента со стороны клиента
     *
     * @return void
     */
    private function changeStatus()
    {
        if (self::$app->statusDemon() == 1) {
            self::$app->stopDemon();
            return 0;
        } else if (self::$app->statusDemon() == 0) {
            self::$app->startDemon();
            return 1;
        }
    }


    public function db_links($tbl = 'allLinks')
    {
        if (!isset($this->links)) {
            $this->links = self::$app->db_links($tbl);
        }
        return $this->links;
    }


    private function getGroup()
    {
        if (isset($_GET['group']) && $_GET['group'] != '') {
            $this->group = $_GET['group'];
        } else {
            // тут решаем какую группу выкидываем изначально
            if (!isset($this->group)) {
                $this->group = array_shift($this->db_links('allLinks')['table']);
            }
        }
        return $this->group;
    }


    private function getLink()
    {
        if (isset($_GET['frame']) && $_GET['frame'] != '') {
            return $_GET['frame'];
        }

        foreach ($this->db_links('allLinks')['table'] as $id => $val) {
            if ($val == $this->getGroup()) {
                return $this->db_links('allLinks')['link'][$id];
                break;
            }
        }
    }


    private function getWeek()
    {
        if (isset($_GET['chb'])) {
            $this->chb = $_GET['chb'];
        } else {
            $this->chb = 3;
        }
        return $this->chb;
    }


    private function addconfig(string $key, string $conf)
    {
        //if (!preg_match('/[/d]+[A-Z]+/i', $conf)) return false;
        return self::$app->iniSet($key, $conf);
    }

    /**
     * Интерфейс функции Application::htmlout()
     *
     * @param string $text
     * @return string
     */
    private function html($text)
    {
        echo self::$app->htmlout($text);
    }


    /**
     * Обработка данных массива об обновленном расписании
     *
     * @param array $data
     * @return string
     */
    private function result(array $data)
    {
        for ($i = 3; $i < count($data); $i++) {
            $result[] = basename($data[$i]);
        }
        return implode("<br \n>", $result);
    }


    /**
     * Подгружаемый контент к странице
     *
     * @param string $some
     * @return void
     */
    private function add_content(string $some)
    {
        switch ($some) {
            case 'adm':
                include_once $_SERVER['DOCUMENT_ROOT'] . '/onload/admin.html.php';
                break;
            case 'toAdm':
                include_once $_SERVER['DOCUMENT_ROOT'] . '/onload/enter.html.php';
                break;
            case 'result':
                include_once $_SERVER['DOCUMENT_ROOT'] . '/menu/result.html.php';
                break;
            case 'err':
                include_once $_SERVER['DOCUMENT_ROOT'] . '/menu/errors.html.php';
                break;
            case 'config':
                include_once $_SERVER['DOCUMENT_ROOT'] . '/menu/config.html.php';
                break;
            case 'main':
                include_once $_SERVER['DOCUMENT_ROOT'] . '/menu/main.html.php';
                break;
            case 'shed':
                include_once $_SERVER['DOCUMENT_ROOT'] . '/menu/shed.html.php';
                break;
            case 'shed_inner':
                include_once $_SERVER['DOCUMENT_ROOT'] . '/menu/shedtext.html.php';
                break;
            case 'frame':
                include_once $_SERVER['DOCUMENT_ROOT'] . '/menu/frame.html.php';
        }
    }

    private function update_db(string $group, string $params, int $id)
    {
        return self::$app->update_shed($group, $params, $id);
    }


    private function delete_db(string $group, int $id)
    {
        return self::$app->delete_shed($group, $id);
    }


    private function insert_db(string $group, string $value)
    {
        return self::$app->insert_shed($group, $value);
    }



    private function get_shed(string $name, $where = 3)
    {
        $shed = [];
        $j = 1;
        if (!($data = self::$app->get_shed($name, $where))) {
            return false;
        }
        $week = [0, 100, 200];
        for ($i = 0; $i < count($data); $i++) {
            for ($j = 1; $j < 8; $j++) {
                if ($data[$i]['day_id'] == $j) {
                    $shed[$j][$data[$i]['lesson_id']][$week[$data[$i]['week_id']]++][$data[$i]['room']][$data[$i]['id']] = $data[$i]['name'];
                    ksort($shed);
                    ksort($shed[$j]);
                }
            }
        }
        //unset($data, $week);
        return  $shed;
    }
    
    
    private function setStat($wh)
    {
        return self::$app->setStat($wh);
    }
    

    private function getLastStat()
    {
        if (!isset($this->stat)) {
            for ($i = 6; $i >= 0; $i--) {
                $this->stat['NU'][date('Y-m-d', strtotime("-$i day"))] = self::$app->getLastStat('NU', date('Y-m-d', strtotime("-$i day")))[0]['SUM'];
                $this->stat['LU'][date('Y-m-d', strtotime("-$i day"))] = self::$app->getLastStat('LU', date('Y-m-d', strtotime("-$i day")))[0]['SUM'] + self::$app->getLastStat('NU', date('Y-m-d', strtotime("-$i day")))[0]['SUM'];
            }
        }
        return $this->stat;
    }



    private function getFaculty(array $rsp)
    {
        $res = [];
        //$rsp = preg_replace('/\s*(.doc)*(x)*/u', '', $rsp);
        foreach ($rsp as $id => $vl) {
            switch (true) {
                case preg_match('/^ИБ\d/iu', $vl):
                    $res['РТФ']['ИБ'][$id] = $vl;
                    break;
                case preg_match('/^Р\d/iu', $vl):
                    $res['РТФ']['Р'][$id] = $vl;
                    break;
                case preg_match('/^С\d/iu', $vl):
                    $res['СВФ']['С'][$id] = $vl;
                    break;
                case preg_match('/^УВТБ\d/iu', $vl):
                    $res['СВФ']['УВТБ'][$id] = $vl;
                    break;
                case preg_match('/^ХБ\d/iu', $vl):
                    $res['СМФ']['ХБ'][$id] = $vl;
                    break;
                case preg_match('/^М\d/iu', $vl):
                    $res['СМФ']['М'][$id] = $vl;
                    break;
                case preg_match('/^ЭЛМ\d/iu', $vl):
                    $res['СМФ']['ЭЛМ'][$id] = $vl;
                    break;
                case preg_match('/^ТТПБ\d/iu', $vl):
                    $res['ТФ']['ТТПБ'][$id] = $vl;
                    break;
                case preg_match('/^ТБ\d/iu', $vl):
                    $res['ТФ']['ТБ'][$id] = $vl;
                    break;
                case preg_match('/^ЭТМБ\d/iu', $vl):
                    $res['ТФ']['ЭТМБ'][$id] = $vl;
                    break;
                default:
                    break;
            }
        }
        return $res;
    }
}


session_start();
try {

    $adm = Admin::getAdmin();
    //var_dump($adm);
    $adm->listen();
} catch (\Exception $ex) {
    echo $ex->getMessage();
}


//echo 'Привет';
